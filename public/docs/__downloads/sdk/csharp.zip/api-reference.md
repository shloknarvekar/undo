# Reference

Every operation below is shown in its throwing form. On an error status it throws `ApiException<TError>` — the status code, headers, content type and the operation's error type, `RawError` (the raw body) when the spec declares none — and where an operation offers an `…AsResult` sibling, that sibling returns `ApiResult<TResponse, TError>` instead. A request that produces no usable response surfaces as `SdkConnectionException` or `SdkTimeoutException`, a body that does not match the documented response type as `ResponseDeserializationException`, and a credential that cannot be applied as `AuthSchemeException`; all of them derive from `SdkException` and name the failed call. See [README → Error Handling](README.md#error-handling).

> Source: [UndoApiClient](src/UndoApi/UndoApiClient.cs)

## MandateRequests

> Source: [MandateRequests](src/UndoApi/Api/MandateRequests.cs)

<details>
<summary><code>Task&lt;MandateRequestActionResult&gt; ActOnMandateRequest(ActOnMandateRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

- `answer`: answers the agent's open questions; the draft is re-read from the new text.
- `prepare`: the exact mandate this device's key must sign.
- `sign`: stores the signed mandate; it must match the request byte for byte (same words, limits and agent).

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.MandateRequests.ActOnMandateRequest(new ActOnMandateRequest
    {
        RequestId = Guid.Parse("7d1f0c2a-3b4e-4f5a-9c6d-8e7f1a2b3c4d"),
        Body = new AnswerAction { Answers = new Dictionary<string, string> { ["What size?"] = "M" } },
    });
    // TODO: Handle 'response' of type MandateRequestActionResult
}
catch (ApiException<ActOnMandateRequestError> ex)
{
    if (ex.Error.TryGetError(out var error))
    {
        // TODO: Handle 'error' of type Error
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[ActOnMandateRequest](src/UndoApi/Requests/MandateRequests/ActOnMandateRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[MandateRequestActionResult](src/UndoApi/Models/AnyOf/MandateRequestActionResult.cs)</code>

**OnError**: <code>[ApiException](src/UndoApi/Core/Exceptions/ApiException.cs)&lt;[ActOnMandateRequestError](src/UndoApi/Errors/ActOnMandateRequestError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;MandateRequest&gt; GetMandateRequest(GetMandateRequestOperationRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

The draft an outside agent asked the shopper to sign, who is asking, and whether it is signed yet.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.MandateRequests.GetMandateRequest(new GetMandateRequestOperationRequest
    {
        RequestId = Guid.Parse("7d1f0c2a-3b4e-4f5a-9c6d-8e7f1a2b3c4d"),
    });
    // TODO: Handle 'response' of type MandateRequest
}
catch (ApiException<GetMandateRequestError> ex)
{
    if (ex.Error.TryGetError(out var error))
    {
        // TODO: Handle 'error' of type Error
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[GetMandateRequestOperationRequest](src/UndoApi/Requests/MandateRequests/GetMandateRequestOperationRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[MandateRequest](src/UndoApi/Models/MandateRequest.cs)</code>

**OnError**: <code>[ApiException](src/UndoApi/Core/Exceptions/ApiException.cs)&lt;[GetMandateRequestError](src/UndoApi/Errors/GetMandateRequestError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

## Mandates

> Source: [Mandates](src/UndoApi/Api/Mandates.cs)

<details>
<summary><code>Task&lt;DraftResult&gt; DraftMandate(DraftMandateOperationRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Turns a plain request into structured limits for the shopper to review. Nothing is stored. Rate limited per visitor.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Mandates.DraftMandate(new DraftMandateOperationRequest
    {
        Body = new DraftMandateRequest { Request = "A black hoodie in size M under $80" },
    });
    // TODO: Handle 'response' of type DraftResult
}
catch (ApiException<DraftMandateError> ex)
{
    if (ex.Error.TryGetError(out var error))
    {
        // TODO: Handle 'error' of type Error
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[DraftMandateOperationRequest](src/UndoApi/Requests/Mandates/DraftMandateOperationRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[DraftResult](src/UndoApi/Models/DraftResult.cs)</code>

**OnError**: <code>[ApiException](src/UndoApi/Core/Exceptions/ApiException.cs)&lt;[DraftMandateError](src/UndoApi/Errors/DraftMandateError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;MandateView&gt; GetMandate(GetMandateRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

The mandate, its status, the search it permits, and a fresh check of its digest, signature and event chain.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Mandates.GetMandate(new GetMandateRequest
    {
        MandateId = Guid.Parse("2f4069f0-2367-4f08-acc6-d9cf1cf6669a"),
    });
    // TODO: Handle 'response' of type MandateView
}
catch (ApiException<GetMandateError> ex)
{
    if (ex.Error.TryGetError(out var error))
    {
        // TODO: Handle 'error' of type Error
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[GetMandateRequest](src/UndoApi/Requests/Mandates/GetMandateRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[MandateView](src/UndoApi/Models/MandateView.cs)</code>

**OnError**: <code>[ApiException](src/UndoApi/Core/Exceptions/ApiException.cs)&lt;[GetMandateError](src/UndoApi/Errors/GetMandateError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;PreparedMandate&gt; PrepareMandate(PrepareMandateRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Returns the mandate the shopper's device must sign and the exact `signingMessage`
(`undo-intent-mandate-v1:<sha256 of the canonical mandate JSON>`). Stateless; nothing is stored.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Mandates.PrepareMandate(new PrepareMandateRequest
    {
        Body = new PrepareMandate
        {
            Request = "A black hoodie in size M under $80",
            Draft = new IntentDraft
            {
                Item = "black hoodie",
                Category = "hoodie",
                Quantity = 1,
                MaxPrice = 80d,
                Currency = "USD",
                Attributes = new Dictionary<string, string> { ["color"] = "black", ["size"] = "M" },
                MustAsk = [],
            },
            ShopperKey = "aHBQ5B27O2BiDV0oWgOigpsXZKjOfhcYYMch5pZ5H0c=",
        },
    });
    // TODO: Handle 'response' of type PreparedMandate
}
catch (ApiException<PrepareMandateError> ex)
{
    if (ex.Error.TryGetError(out var error))
    {
        // TODO: Handle 'error' of type Error
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[PrepareMandateRequest](src/UndoApi/Requests/Mandates/PrepareMandateRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[PreparedMandate](src/UndoApi/Models/PreparedMandate.cs)</code>

**OnError**: <code>[ApiException](src/UndoApi/Core/Exceptions/ApiException.cs)&lt;[PrepareMandateError](src/UndoApi/Errors/PrepareMandateError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;StoredMandate&gt; StoreMandate(StoreMandateRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Re-verifies the signature, freshness, expiry and readiness, then writes the first event of the mandate's hash chain.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Mandates.StoreMandate(new StoreMandateRequest
    {
        Body = new SignedMandate
        {
            Mandate = new IntentMandate
            {
                Version = 1,
                Id = Guid.Parse("2f4069f0-2367-4f08-acc6-d9cf1cf6669a"),
                CreatedAt = DateTimeOffset.Parse("2026-10-20T04:18:17.928Z"),
                ExpiresAt = DateTimeOffset.Parse("2026-11-03T04:18:17.928Z"),
                ShopperKey = "aHBQ5B27O2BiDV0oWgOigpsXZKjOfhcYYMch5pZ5H0c=",
                Request = "Buy me black men's running shoes, size 10, under $120",
                Intent = new IntentDraft
                {
                    Item = "running shoes",
                    Category = "running shoes",
                    Quantity = 1,
                    MaxPrice = 120d,
                    Currency = "USD",
                    Attributes = new Dictionary<string, string> { ["size"] = "10", ["color"] = "black" },
                    Gender = Gender.Male,
                    MustAsk = [],
                },
            },
            Signature = "derQBgmEoL8kvl3vfHVsmqTVAkGTSvb2ShqDoVFKdSC5U5PpGkYAUsDzgSd80QyEpGEPh4966mrEQ9CzBw0IDA==",
        },
    });
    // TODO: Handle 'response' of type StoredMandate
}
catch (ApiException<StoreMandateError> ex)
{
    if (ex.Error.TryGetError(out var error))
    {
        // TODO: Handle 'error' of type Error
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[StoreMandateRequest](src/UndoApi/Requests/Mandates/StoreMandateRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[StoredMandate](src/UndoApi/Models/StoredMandate.cs)</code>

**OnError**: <code>[ApiException](src/UndoApi/Core/Exceptions/ApiException.cs)&lt;[StoreMandateError](src/UndoApi/Errors/StoreMandateError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

## Merchant

> Source: [Merchant](src/UndoApi/Api/Merchant.cs)

<details>
<summary><code>Task&lt;MerchantRules&gt; GetMerchantRules(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

The rules the store applies to agents at checkout: block below a trust score, lengthen the undo window below a score, or accept only registered operators.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Merchant.GetMerchantRules();
    // TODO: Handle 'response' of type MerchantRules
}
catch (ApiException<RawError> ex)
{
    // TODO: Handle 'ex.Error' of type RawError
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[MerchantRules](src/UndoApi/Models/MerchantRules.cs)</code>

**OnError**: <code>[ApiException](src/UndoApi/Core/Exceptions/ApiException.cs)&lt;[RawError](src/UndoApi/Core/ErrorResponse/RawError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;ActivityFeed&gt; ListMerchantActivity(ListMerchantActivityRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Every step Undo records, newest first (up to 60). Pass `after` to get only events newer than that id.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Merchant.ListMerchantActivity(new ListMerchantActivityRequest { After = 1200 });
    // TODO: Handle 'response' of type ActivityFeed
}
catch (ApiException<RawError> ex)
{
    // TODO: Handle 'ex.Error' of type RawError
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[ListMerchantActivityRequest](src/UndoApi/Requests/Merchant/ListMerchantActivityRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[ActivityFeed](src/UndoApi/Models/ActivityFeed.cs)</code>

**OnError**: <code>[ApiException](src/UndoApi/Core/Exceptions/ApiException.cs)&lt;[RawError](src/UndoApi/Core/ErrorResponse/RawError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;MerchantAgents&gt; ListMerchantAgents(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Every agent that has shopped here, its record and trust score with every point explained, and what the store's rules do to it.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Merchant.ListMerchantAgents();
    // TODO: Handle 'response' of type MerchantAgents
}
catch (ApiException<RawError> ex)
{
    // TODO: Handle 'ex.Error' of type RawError
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[MerchantAgents](src/UndoApi/Models/MerchantAgents.cs)</code>

**OnError**: <code>[ApiException](src/UndoApi/Core/Exceptions/ApiException.cs)&lt;[RawError](src/UndoApi/Core/ErrorResponse/RawError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;MerchantOrders&gt; ListMerchantOrders(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Every agent order (latest 300) with its verdict, who pays and any agent payout, plus headline numbers.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Merchant.ListMerchantOrders();
    // TODO: Handle 'response' of type MerchantOrders
}
catch (ApiException<RawError> ex)
{
    // TODO: Handle 'ex.Error' of type RawError
}
```

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[MerchantOrders](src/UndoApi/Models/MerchantOrders.cs)</code>

**OnError**: <code>[ApiException](src/UndoApi/Core/Exceptions/ApiException.cs)&lt;[RawError](src/UndoApi/Core/ErrorResponse/RawError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;ResolveOrderResult&gt; ResolveOrder(ResolveOrderOperationRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

The merchant's side of an Undo. Sandbox only.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Merchant.ResolveOrder(new ResolveOrderOperationRequest
    {
        OrderId = Guid.Parse("edd288bc-42d0-41d3-9b87-14915f3ff2c6"),
        Body = new ResolveOrderRequest { Action = ResolveAction.RetrySettlement },
    });
    // TODO: Handle 'response' of type ResolveOrderResult
}
catch (ApiException<ResolveOrderError> ex)
{
    if (ex.Error.TryGetError(out var error))
    {
        // TODO: Handle 'error' of type Error
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[ResolveOrderOperationRequest](src/UndoApi/Requests/Merchant/ResolveOrderOperationRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[ResolveOrderResult](src/UndoApi/Models/ResolveOrderResult.cs)</code>

**OnError**: <code>[ApiException](src/UndoApi/Core/Exceptions/ApiException.cs)&lt;[ResolveOrderError](src/UndoApi/Errors/ResolveOrderError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;MerchantRules&gt; UpdateMerchantRules(UpdateMerchantRulesRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Applies from the next checkout, for Undo's agent and every MCP agent. Each change is recorded in the store's event chain.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Merchant.UpdateMerchantRules(new UpdateMerchantRulesRequest
    {
        Body = new MerchantRules { BlockBelow = 1, ExtendBelow = 50, ExtendMinutes = 360, BlockUnverified = false },
    });
    // TODO: Handle 'response' of type MerchantRules
}
catch (ApiException<UpdateMerchantRulesError> ex)
{
    if (ex.Error.TryGetError(out var error))
    {
        // TODO: Handle 'error' of type Error
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[UpdateMerchantRulesRequest](src/UndoApi/Requests/Merchant/UpdateMerchantRulesRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[MerchantRules](src/UndoApi/Models/MerchantRules.cs)</code>

**OnError**: <code>[ApiException](src/UndoApi/Core/Exceptions/ApiException.cs)&lt;[UpdateMerchantRulesError](src/UndoApi/Errors/UpdateMerchantRulesError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

## Orders

> Source: [Orders](src/UndoApi/Api/Orders.cs)

<details>
<summary><code>Task&lt;OrderView&gt; GetOrder(GetOrderRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

The purchase, the live undo window, the mandate behind it, and its verified event chain. Each event carries its proof.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Orders.GetOrder(new GetOrderRequest
    {
        OrderId = Guid.Parse("edd288bc-42d0-41d3-9b87-14915f3ff2c6"),
    });
    // TODO: Handle 'response' of type OrderView
}
catch (ApiException<GetOrderError> ex)
{
    if (ex.Error.TryGetError(out var error))
    {
        // TODO: Handle 'error' of type Error
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[GetOrderRequest](src/UndoApi/Requests/Orders/GetOrderRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[OrderView](src/UndoApi/Models/OrderView.cs)</code>

**OnError**: <code>[ApiException](src/UndoApi/Core/Exceptions/ApiException.cs)&lt;[GetOrderError](src/UndoApi/Errors/GetOrderError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;Evidence&gt; GetOrderEvidence(GetOrderEvidenceRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Everything needed to check an order without trusting Undo: the raw hash-chained events exactly as hashed and
the signed mandate exactly as stored. Nothing is pre-verified, on purpose.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Orders.GetOrderEvidence(new GetOrderEvidenceRequest
    {
        OrderId = Guid.Parse("edd288bc-42d0-41d3-9b87-14915f3ff2c6"),
    });
    // TODO: Handle 'response' of type Evidence
}
catch (ApiException<GetOrderEvidenceError> ex)
{
    if (ex.Error.TryGetError(out var error))
    {
        // TODO: Handle 'error' of type Error
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[GetOrderEvidenceRequest](src/UndoApi/Requests/Orders/GetOrderEvidenceRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[Evidence](src/UndoApi/Models/Evidence.cs)</code>

**OnError**: <code>[ApiException](src/UndoApi/Core/Exceptions/ApiException.cs)&lt;[GetOrderEvidenceError](src/UndoApi/Errors/GetOrderEvidenceError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;UndoResult&gt; UndoOrder(UndoOrderRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

The Undo button. Must be signed by the mandate's shopper key over
`undo-request-v1:<orderId>:<sha256 hex of reason>:<sha256 hex of photo bytes, or ->:<requestedAt>`.
`requestedAt` must be within 15 minutes of now. Runs the fault check, then routes the money: a void inside
the window, or a refund, merchant claim, return or human review after capture. Rate limited per visitor.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Orders.UndoOrder(new UndoOrderRequest
    {
        OrderId = Guid.Parse("edd288bc-42d0-41d3-9b87-14915f3ff2c6"),
        Body = new UndoRequest
        {
            Reason = "This isn't what I asked for.",
            RequestedAt = DateTimeOffset.Parse("2026-10-20T16:30:00Z"),
            Signature = "derQBgmEoL8kvl3vfHVsmqTVAkGTSvb2ShqDoVFKdSC5U5PpGkYAUsDzgSd80QyEpGEPh4966mrEQ9CzBw0IDA==",
        },
    });
    // TODO: Handle 'response' of type UndoResult
}
catch (ApiException<UndoOrderError> ex)
{
    if (ex.Error.TryGetError(out var error))
    {
        // TODO: Handle 'error' of type Error
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[UndoOrderRequest](src/UndoApi/Requests/Orders/UndoOrderRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[UndoResult](src/UndoApi/Models/UndoResult.cs)</code>

**OnError**: <code>[ApiException](src/UndoApi/Core/Exceptions/ApiException.cs)&lt;[UndoOrderError](src/UndoApi/Errors/UndoOrderError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

## Products

> Source: [Products](src/UndoApi/Api/Products.cs)

<details>
<summary><code>Task&lt;ProductDetail&gt; GetProduct(GetProductRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Fresh product detail resolved to the requested variant. Pass options as `option_<Name>=<value>` query
parameters, for example `option_Size=M&option_Color=Black`. `relaxed` lists any option the catalog could not honor.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Products.GetProduct(new GetProductRequest
    {
        ProductId = "w25336I",
        Options = new Dictionary<string, string> { ["option_Size"] = "10.5", ["option_Color"] = "Black" },
    });
    // TODO: Handle 'response' of type ProductDetail
}
catch (ApiException<GetProductError> ex)
{
    if (ex.Error.TryGetError(out var error))
    {
        // TODO: Handle 'error' of type Error
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[GetProductRequest](src/UndoApi/Requests/Products/GetProductRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[ProductDetail](src/UndoApi/Models/ProductDetail.cs)</code>

**OnError**: <code>[ApiException](src/UndoApi/Core/Exceptions/ApiException.cs)&lt;[GetProductError](src/UndoApi/Errors/GetProductError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

<details>
<summary><code>Task&lt;ProductSearchResult&gt; SearchProducts(SearchProductsRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Searches the live catalog with structured filters. Rate limited per visitor.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Products.SearchProducts(new SearchProductsRequest
    {
        Body = new ProductSearch { Query = "black hoodie", MaxPrice = 80d, Color = "black", Limit = 5 },
    });
    // TODO: Handle 'response' of type ProductSearchResult
}
catch (ApiException<SearchProductsError> ex)
{
    if (ex.Error.TryGetError(out var error))
    {
        // TODO: Handle 'error' of type Error
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[SearchProductsRequest](src/UndoApi/Requests/Products/SearchProductsRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[ProductSearchResult](src/UndoApi/Models/ProductSearchResult.cs)</code>

**OnError**: <code>[ApiException](src/UndoApi/Core/Exceptions/ApiException.cs)&lt;[SearchProductsError](src/UndoApi/Errors/SearchProductsError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

## Service

> Source: [Service](src/UndoApi/Api/Service.cs)

<details>
<summary><code>Task&lt;Health&gt; GetHealth(GetHealthRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Shallow health check. With `deep`, also proves the service can reach PayPal sandbox and the database. Never returns secret values.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Service.GetHealth(new GetHealthRequest { Deep = "1" });
    // TODO: Handle 'response' of type Health
}
catch (ApiException<GetHealthError> ex)
{
    if (ex.Error.TryGetHealth(out var error))
    {
        // TODO: Handle 'error' of type Health
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[GetHealthRequest](src/UndoApi/Requests/Service/GetHealthRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[Health](src/UndoApi/Models/Health.cs)</code>

**OnError**: <code>[ApiException](src/UndoApi/Core/Exceptions/ApiException.cs)&lt;[GetHealthError](src/UndoApi/Errors/GetHealthError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

## Shopping

> Source: [Shopping](src/UndoApi/Api/Shopping.cs)

<details>
<summary><code>Task&lt;ShopResult&gt; ShopMandate(ShopMandateOperationRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default);</code></summary>

<dl>
<dd>

### Description

<dl>
<dd>

Undo's agent searches, checks the cart against the signed limits, and opens a PayPal checkout in AUTHORIZE
mode. Without a saved wallet the shopper approves at `approveUrl`; with one (and only if the mandate allows it)
the money is held straight away. One live purchase per mandate. Rate limited per visitor.

</dd>
</dl>

### Usage

<dl>
<dd>

```csharp
try
{
    var response = await client.Shopping.ShopMandate(new ShopMandateOperationRequest
    {
        MandateId = Guid.Parse("2f4069f0-2367-4f08-acc6-d9cf1cf6669a"),
        Body = new ShopMandateRequest(),
    });
    // TODO: Handle 'response' of type ShopResult
}
catch (ApiException<ShopMandateError> ex)
{
    if (ex.Error.TryGetError(out var error))
    {
        // TODO: Handle 'error' of type Error
    }
}
```

</dd>
</dl>

### Request

<dl>
<dd>

<code>[ShopMandateOperationRequest](src/UndoApi/Requests/Shopping/ShopMandateOperationRequest.cs)</code>

</dd>
</dl>

### Response

<dl>
<dd>

**OnSuccess**: <code>[ShopResult](src/UndoApi/Models/ShopResult.cs)</code>

**OnError**: <code>[ApiException](src/UndoApi/Core/Exceptions/ApiException.cs)&lt;[ShopMandateError](src/UndoApi/Errors/ShopMandateError.cs)&gt;</code>

</dd>
</dl>

</dd>
</dl>

</details>

