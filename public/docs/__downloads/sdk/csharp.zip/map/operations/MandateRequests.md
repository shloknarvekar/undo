<!-- Generated file — do not edit; regenerated with the SDK. -->

# MandateRequests — operations

Accessor: `client.MandateRequests` · Source: `src/UndoApi/Api/MandateRequests.cs` · 2 operations

**Type sources**: the file declaring each type an operation names (`RawError` excluded — see sdk-map.md).

### ActOnMandateRequest

- **Signature**: `ActOnMandateRequest(ActOnMandateRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `RequestId`, `Body`
- **Returns**: `MandateRequestActionResult`
- **Error**: `ApiException<ActOnMandateRequestError>` — **Case A (typed)**
- **Error accessors**: `TryGetError(out Error)` [400, 404, 409, 422] · `TryGetRateLimited(out RateLimited)` [429] · `TryGetRawError(out RawError)` [fallback]

| Type | Source |
| --- | --- |
| `ActOnMandateRequest` | `src/UndoApi/Requests/MandateRequests/ActOnMandateRequest.cs` |
| `MandateRequestAction` | `src/UndoApi/Models/OneOf/MandateRequestAction.cs` |
| `MandateRequestActionResult` | `src/UndoApi/Models/AnyOf/MandateRequestActionResult.cs` |
| `ActOnMandateRequestError` | `src/UndoApi/Errors/ActOnMandateRequestError.cs` |
| `Error` | `src/UndoApi/Models/Error.cs` |
| `RateLimited` | `src/UndoApi/Models/RateLimited.cs` |

### GetMandateRequest

- **Signature**: `GetMandateRequest(GetMandateRequestOperationRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `RequestId`
- **Returns**: `MandateRequest`
- **Error**: `ApiException<GetMandateRequestError>` — **Case A (typed)**
- **Error accessors**: `TryGetError(out Error)` [404] · `TryGetRawError(out RawError)` [fallback]

| Type | Source |
| --- | --- |
| `GetMandateRequestOperationRequest` | `src/UndoApi/Requests/MandateRequests/GetMandateRequestOperationRequest.cs` |
| `MandateRequest` | `src/UndoApi/Models/MandateRequest.cs` |
| `GetMandateRequestError` | `src/UndoApi/Errors/GetMandateRequestError.cs` |
| `Error` | `src/UndoApi/Models/Error.cs` |

