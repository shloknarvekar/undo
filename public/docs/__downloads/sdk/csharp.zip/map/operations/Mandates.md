<!-- Generated file — do not edit; regenerated with the SDK. -->

# Mandates — operations

Accessor: `client.Mandates` · Source: `src/UndoApi/Api/Mandates.cs` · 4 operations

**Type sources**: the file declaring each type an operation names (`RawError` excluded — see sdk-map.md).

### DraftMandate

- **Signature**: `DraftMandate(DraftMandateOperationRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `Body`
- **Returns**: `DraftResult`
- **Error**: `ApiException<DraftMandateError>` — **Case A (typed)**
- **Error accessors**: `TryGetError(out Error)` [400, 502, 503] · `TryGetRateLimited(out RateLimited)` [429] · `TryGetRawError(out RawError)` [fallback]

| Type | Source |
| --- | --- |
| `DraftMandateOperationRequest` | `src/UndoApi/Requests/Mandates/DraftMandateOperationRequest.cs` |
| `DraftMandateRequest` | `src/UndoApi/Models/DraftMandateRequest.cs` |
| `DraftResult` | `src/UndoApi/Models/DraftResult.cs` |
| `DraftMandateError` | `src/UndoApi/Errors/DraftMandateError.cs` |
| `Error` | `src/UndoApi/Models/Error.cs` |
| `RateLimited` | `src/UndoApi/Models/RateLimited.cs` |

### GetMandate

- **Signature**: `GetMandate(GetMandateRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `MandateId`
- **Returns**: `MandateView`
- **Error**: `ApiException<GetMandateError>` — **Case A (typed)**
- **Error accessors**: `TryGetError(out Error)` [404] · `TryGetRawError(out RawError)` [fallback]

| Type | Source |
| --- | --- |
| `GetMandateRequest` | `src/UndoApi/Requests/Mandates/GetMandateRequest.cs` |
| `MandateView` | `src/UndoApi/Models/MandateView.cs` |
| `GetMandateError` | `src/UndoApi/Errors/GetMandateError.cs` |
| `Error` | `src/UndoApi/Models/Error.cs` |

### PrepareMandate

- **Signature**: `PrepareMandate(PrepareMandateRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `Body`
- **Returns**: `PreparedMandate`
- **Error**: `ApiException<PrepareMandateError>` — **Case A (typed)**
- **Error accessors**: `TryGetError(out Error)` [400] · `TryGetNotReady(out NotReady)` [422] · `TryGetRawError(out RawError)` [fallback]

| Type | Source |
| --- | --- |
| `PrepareMandateRequest` | `src/UndoApi/Requests/Mandates/PrepareMandateRequest.cs` |
| `PrepareMandate` | `src/UndoApi/Models/PrepareMandate.cs` |
| `PreparedMandate` | `src/UndoApi/Models/PreparedMandate.cs` |
| `PrepareMandateError` | `src/UndoApi/Errors/PrepareMandateError.cs` |
| `Error` | `src/UndoApi/Models/Error.cs` |
| `NotReady` | `src/UndoApi/Models/NotReady.cs` |

### StoreMandate

- **Signature**: `StoreMandate(StoreMandateRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `Body`
- **Returns**: `StoredMandate`
- **Error**: `ApiException<StoreMandateError>` — **Case A (typed)**
- **Error accessors**: `TryGetError(out Error)` [400, 403, 409, 422] · `TryGetRawError(out RawError)` [fallback]

| Type | Source |
| --- | --- |
| `StoreMandateRequest` | `src/UndoApi/Requests/Mandates/StoreMandateRequest.cs` |
| `SignedMandate` | `src/UndoApi/Models/SignedMandate.cs` |
| `StoredMandate` | `src/UndoApi/Models/StoredMandate.cs` |
| `StoreMandateError` | `src/UndoApi/Errors/StoreMandateError.cs` |
| `Error` | `src/UndoApi/Models/Error.cs` |

