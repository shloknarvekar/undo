<!-- Generated file — do not edit; regenerated with the SDK. -->

# Merchant — operations

Accessor: `client.Merchant` · Source: `src/UndoApi/Api/Merchant.cs` · 6 operations

**Type sources**: the file declaring each type an operation names (`RawError` excluded — see sdk-map.md).

### GetMerchantRules

- **Signature**: `GetMerchantRules(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Returns**: `MerchantRules`
- **Error**: `ApiException<RawError>` — **Case B**

| Type | Source |
| --- | --- |
| `MerchantRules` | `src/UndoApi/Models/MerchantRules.cs` |

### ListMerchantActivity

- **Signature**: `ListMerchantActivity(ListMerchantActivityRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Query params (wire ← C#)**: `after` ← `After`
- **Returns**: `ActivityFeed`
- **Error**: `ApiException<RawError>` — **Case B**

| Type | Source |
| --- | --- |
| `ListMerchantActivityRequest` | `src/UndoApi/Requests/Merchant/ListMerchantActivityRequest.cs` |
| `ActivityFeed` | `src/UndoApi/Models/ActivityFeed.cs` |

### ListMerchantAgents

- **Signature**: `ListMerchantAgents(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Returns**: `MerchantAgents`
- **Error**: `ApiException<RawError>` — **Case B**

| Type | Source |
| --- | --- |
| `MerchantAgents` | `src/UndoApi/Models/MerchantAgents.cs` |

### ListMerchantOrders

- **Signature**: `ListMerchantOrders(RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Returns**: `MerchantOrders`
- **Error**: `ApiException<RawError>` — **Case B**

| Type | Source |
| --- | --- |
| `MerchantOrders` | `src/UndoApi/Models/MerchantOrders.cs` |

### ResolveOrder

- **Signature**: `ResolveOrder(ResolveOrderOperationRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `OrderId`, `Body`
- **Returns**: `ResolveOrderResult`
- **Error**: `ApiException<ResolveOrderError>` — **Case A (typed)**
- **Error accessors**: `TryGetError(out Error)` [400, 403, 404, 409, 502] · `TryGetRawError(out RawError)` [fallback]

| Type | Source |
| --- | --- |
| `ResolveOrderOperationRequest` | `src/UndoApi/Requests/Merchant/ResolveOrderOperationRequest.cs` |
| `ResolveOrderRequest` | `src/UndoApi/Models/ResolveOrderRequest.cs` |
| `ResolveOrderResult` | `src/UndoApi/Models/ResolveOrderResult.cs` |
| `ResolveOrderError` | `src/UndoApi/Errors/ResolveOrderError.cs` |
| `Error` | `src/UndoApi/Models/Error.cs` |

### UpdateMerchantRules

- **Signature**: `UpdateMerchantRules(UpdateMerchantRulesRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `Body`
- **Returns**: `MerchantRules`
- **Error**: `ApiException<UpdateMerchantRulesError>` — **Case A (typed)**
- **Error accessors**: `TryGetError(out Error)` [400] · `TryGetRateLimited(out RateLimited)` [429] · `TryGetRawError(out RawError)` [fallback]

| Type | Source |
| --- | --- |
| `UpdateMerchantRulesRequest` | `src/UndoApi/Requests/Merchant/UpdateMerchantRulesRequest.cs` |
| `MerchantRules` | `src/UndoApi/Models/MerchantRules.cs` |
| `UpdateMerchantRulesError` | `src/UndoApi/Errors/UpdateMerchantRulesError.cs` |
| `Error` | `src/UndoApi/Models/Error.cs` |
| `RateLimited` | `src/UndoApi/Models/RateLimited.cs` |

