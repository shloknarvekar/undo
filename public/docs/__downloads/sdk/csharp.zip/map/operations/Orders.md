<!-- Generated file — do not edit; regenerated with the SDK. -->

# Orders — operations

Accessor: `client.Orders` · Source: `src/UndoApi/Api/Orders.cs` · 3 operations

**Type sources**: the file declaring each type an operation names (`RawError` excluded — see sdk-map.md).

### GetOrder

- **Signature**: `GetOrder(GetOrderRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `OrderId`
- **Returns**: `OrderView`
- **Error**: `ApiException<GetOrderError>` — **Case A (typed)**
- **Error accessors**: `TryGetError(out Error)` [404] · `TryGetRawError(out RawError)` [fallback]

| Type | Source |
| --- | --- |
| `GetOrderRequest` | `src/UndoApi/Requests/Orders/GetOrderRequest.cs` |
| `OrderView` | `src/UndoApi/Models/OrderView.cs` |
| `GetOrderError` | `src/UndoApi/Errors/GetOrderError.cs` |
| `Error` | `src/UndoApi/Models/Error.cs` |

### GetOrderEvidence

- **Signature**: `GetOrderEvidence(GetOrderEvidenceRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `OrderId`
- **Returns**: `Evidence`
- **Error**: `ApiException<GetOrderEvidenceError>` — **Case A (typed)**
- **Error accessors**: `TryGetError(out Error)` [404] · `TryGetRawError(out RawError)` [fallback]

| Type | Source |
| --- | --- |
| `GetOrderEvidenceRequest` | `src/UndoApi/Requests/Orders/GetOrderEvidenceRequest.cs` |
| `Evidence` | `src/UndoApi/Models/Evidence.cs` |
| `GetOrderEvidenceError` | `src/UndoApi/Errors/GetOrderEvidenceError.cs` |
| `Error` | `src/UndoApi/Models/Error.cs` |

### UndoOrder

- **Signature**: `UndoOrder(UndoOrderRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `OrderId`, `Body`
- **Returns**: `UndoResult`
- **Error**: `ApiException<UndoOrderError>` — **Case A (typed)**
- **Error accessors**: `TryGetError(out Error)` [400, 403, 404, 409, 413, 422, 502] · `TryGetRateLimited(out RateLimited)` [429] · `TryGetRawError(out RawError)` [fallback]

| Type | Source |
| --- | --- |
| `UndoOrderRequest` | `src/UndoApi/Requests/Orders/UndoOrderRequest.cs` |
| `UndoRequest` | `src/UndoApi/Models/UndoRequest.cs` |
| `UndoResult` | `src/UndoApi/Models/UndoResult.cs` |
| `UndoOrderError` | `src/UndoApi/Errors/UndoOrderError.cs` |
| `Error` | `src/UndoApi/Models/Error.cs` |
| `RateLimited` | `src/UndoApi/Models/RateLimited.cs` |

