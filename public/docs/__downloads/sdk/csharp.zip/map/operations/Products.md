<!-- Generated file — do not edit; regenerated with the SDK. -->

# Products — operations

Accessor: `client.Products` · Source: `src/UndoApi/Api/Products.cs` · 2 operations

**Type sources**: the file declaring each type an operation names (`RawError` excluded — see sdk-map.md).

### GetProduct

- **Signature**: `GetProduct(GetProductRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `ProductId`
- **Query params (wire ← C#)**: `options` ← `Options`
- **Returns**: `ProductDetail`
- **Error**: `ApiException<GetProductError>` — **Case A (typed)**
- **Error accessors**: `TryGetError(out Error)` [404, 502] · `TryGetRawError(out RawError)` [fallback]

| Type | Source |
| --- | --- |
| `GetProductRequest` | `src/UndoApi/Requests/Products/GetProductRequest.cs` |
| `ProductDetail` | `src/UndoApi/Models/ProductDetail.cs` |
| `GetProductError` | `src/UndoApi/Errors/GetProductError.cs` |
| `Error` | `src/UndoApi/Models/Error.cs` |

### SearchProducts

- **Signature**: `SearchProducts(SearchProductsRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `Body`
- **Returns**: `ProductSearchResult`
- **Error**: `ApiException<SearchProductsError>` — **Case A (typed)**
- **Error accessors**: `TryGetError(out Error)` [400, 502] · `TryGetRateLimited(out RateLimited)` [429] · `TryGetRawError(out RawError)` [fallback]

| Type | Source |
| --- | --- |
| `SearchProductsRequest` | `src/UndoApi/Requests/Products/SearchProductsRequest.cs` |
| `ProductSearch` | `src/UndoApi/Models/ProductSearch.cs` |
| `ProductSearchResult` | `src/UndoApi/Models/ProductSearchResult.cs` |
| `SearchProductsError` | `src/UndoApi/Errors/SearchProductsError.cs` |
| `Error` | `src/UndoApi/Models/Error.cs` |
| `RateLimited` | `src/UndoApi/Models/RateLimited.cs` |

