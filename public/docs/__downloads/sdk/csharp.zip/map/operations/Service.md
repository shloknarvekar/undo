<!-- Generated file — do not edit; regenerated with the SDK. -->

# Service — operations

Accessor: `client.Service` · Source: `src/UndoApi/Api/Service.cs` · 1 operation

**Type sources**: the file declaring each type an operation names (`RawError` excluded — see sdk-map.md).

### GetHealth

- **Signature**: `GetHealth(GetHealthRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
- **Query params (wire ← C#)**: `deep` ← `Deep`
- **Returns**: `Health`
- **Error**: `ApiException<GetHealthError>` — **Case A (typed)**
- **Error accessors**: `TryGetHealth(out Health)` [503] · `TryGetRawError(out RawError)` [fallback]

| Type | Source |
| --- | --- |
| `GetHealthRequest` | `src/UndoApi/Requests/Service/GetHealthRequest.cs` |
| `Health` | `src/UndoApi/Models/Health.cs` |
| `GetHealthError` | `src/UndoApi/Errors/GetHealthError.cs` |

