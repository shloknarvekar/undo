<!-- Generated file — do not edit; regenerated with the SDK. -->

# Shopping — operations

Accessor: `client.Shopping` · Source: `src/UndoApi/Api/Shopping.cs` · 1 operation

**Type sources**: the file declaring each type an operation names (`RawError` excluded — see sdk-map.md).

### ShopMandate

- **Signature**: `ShopMandate(ShopMandateOperationRequest request, RequestOptions? requestOptions = null, CancellationToken cancellationToken = default)`
  - required: `MandateId`
- **Returns**: `ShopResult`
- **Error**: `ApiException<ShopMandateError>` — **Case A (typed)**
- **Error accessors**: `TryGetError(out Error)` [403, 404, 409, 422, 502, 503] · `TryGetRateLimited(out RateLimited)` [429] · `TryGetRawError(out RawError)` [fallback]

| Type | Source |
| --- | --- |
| `ShopMandateOperationRequest` | `src/UndoApi/Requests/Shopping/ShopMandateOperationRequest.cs` |
| `ShopMandateRequest` | `src/UndoApi/Models/ShopMandateRequest.cs` |
| `ShopResult` | `src/UndoApi/Models/ShopResult.cs` |
| `ShopMandateError` | `src/UndoApi/Errors/ShopMandateError.cs` |
| `Error` | `src/UndoApi/Models/Error.cs` |
| `RateLimited` | `src/UndoApi/Models/RateLimited.cs` |

