using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using UndoApi.Core;
using UndoApi.Core.Exceptions;
using UndoApi.Core.Models;
using UndoApi.Core.Request;
using UndoApi.Core.Response;
using UndoApi.Errors;
using UndoApi.Models;
using UndoApi.Models.AnyOf;
using UndoApi.Requests.MandateRequests;

namespace UndoApi.Api;

/// <summary>
/// The shopper's side of a mandate an outside agent asked for.
/// </summary>
public sealed class MandateRequests
{
    private readonly RawClient _rawClient;
    private readonly Server _server;

    internal MandateRequests(RawClient rawClient, Server server)
    {
        _rawClient = rawClient;
        _server = server;
    }

    /// <summary>
    /// Answer, prepare or sign a mandate request
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="MandateRequestActionResult"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="ActOnMandateRequestError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// <list type="bullet">
    ///   <item><description><c>answer</c>: answers the agent's open questions; the draft is re-read from the new text.</description></item>
    ///   <item><description><c>prepare</c>: the exact mandate this device's key must sign.</description></item>
    ///   <item><description><c>sign</c>: stores the signed mandate; it must match the request byte for byte (same words, limits and agent).</description></item>
    /// </list>
    /// </remarks>
    public Task<MandateRequestActionResult> ActOnMandateRequest(ActOnMandateRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/mandate-requests/{requestId}"),
            [new TemplateParam("requestId", request.RequestId)],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Post,
            JsonRequest.Create(request.Body),
            JsonResponse.Create<MandateRequestActionResult>(),
            ActOnMandateRequestError.Response,
            [],
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Get a mandate request
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="MandateRequest"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="GetMandateRequestError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// The draft an outside agent asked the shopper to sign, who is asking, and whether it is signed yet.
    /// </remarks>
    public Task<MandateRequest> GetMandateRequest(GetMandateRequestOperationRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/mandate-requests/{requestId}"),
            [new TemplateParam("requestId", request.RequestId)],
            [],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<MandateRequest>(),
            GetMandateRequestError.Response,
            [],
            requestOptions,
            cancellationToken);
}
