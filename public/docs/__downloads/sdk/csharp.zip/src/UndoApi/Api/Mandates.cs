using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using UndoApi.Core;
using UndoApi.Core.Exceptions;
using UndoApi.Core.Models;
using UndoApi.Core.Request;
using UndoApi.Core.Response;
using UndoApi.Errors;
using UndoApi.Models;
using UndoApi.Requests.Mandates;

namespace UndoApi.Api;

/// <summary>
/// Drafting, preparing, signing and reading shopper-signed intent mandates.
/// </summary>
public sealed class Mandates
{
    private readonly RawClient _rawClient;
    private readonly Server _server;

    internal Mandates(RawClient rawClient, Server server)
    {
        _rawClient = rawClient;
        _server = server;
    }

    /// <summary>
    /// Draft a mandate from the shopper's words
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="DraftResult"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="DraftMandateError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Turns a plain request into structured limits for the shopper to review. Nothing is stored. Rate limited per visitor.
    /// </remarks>
    public Task<DraftResult> DraftMandate(DraftMandateOperationRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/mandates/draft"),
            [],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Post,
            JsonRequest.Create(request.Body),
            JsonResponse.Create<DraftResult>(),
            DraftMandateError.Response,
            [],
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Get a mandate and check its integrity
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="MandateView"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="GetMandateError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// The mandate, its status, the search it permits, and a fresh check of its digest, signature and event chain.
    /// </remarks>
    public Task<MandateView> GetMandate(GetMandateRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/mandates/{mandateId}"),
            [new TemplateParam("mandateId", request.MandateId)],
            [],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<MandateView>(),
            GetMandateError.Response,
            [],
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Build the exact mandate to sign
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="PreparedMandate"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="PrepareMandateError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Returns the mandate the shopper's device must sign and the exact <c>signingMessage</c>
    /// (<c>undo-intent-mandate-v1:&lt;sha256 of the canonical mandate JSON&gt;</c>). Stateless; nothing is stored.
    /// </remarks>
    public Task<PreparedMandate> PrepareMandate(PrepareMandateRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/mandates/prepare"),
            [],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Post,
            JsonRequest.Create(request.Body),
            JsonResponse.Create<PreparedMandate>(),
            PrepareMandateError.Response,
            [],
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Store a signed mandate
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="StoredMandate"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="StoreMandateError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Re-verifies the signature, freshness, expiry and readiness, then writes the first event of the mandate's hash chain.
    /// </remarks>
    public Task<StoredMandate> StoreMandate(StoreMandateRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/mandates"),
            [],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Post,
            JsonRequest.Create(request.Body),
            JsonResponse.Create<StoredMandate>(),
            StoreMandateError.Response,
            [],
            requestOptions,
            cancellationToken);
}
