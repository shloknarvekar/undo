using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using UndoApi.Core;
using UndoApi.Core.ErrorResponse;
using UndoApi.Core.Exceptions;
using UndoApi.Core.Models;
using UndoApi.Core.Request;
using UndoApi.Core.Response;
using UndoApi.Errors;
using UndoApi.Models;
using UndoApi.Requests.Merchant;

namespace UndoApi.Api;

/// <summary>
/// The store's view. Sandbox demo store; merchant sign-in comes with production use.
/// </summary>
public sealed class Merchant
{
    private readonly RawClient _rawClient;
    private readonly Server _server;

    internal Merchant(RawClient rawClient, Server server)
    {
        _rawClient = rawClient;
        _server = server;
    }

    /// <summary>
    /// Get the store's agent rules
    /// </summary>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="MerchantRules"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="RawError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// The rules the store applies to agents at checkout: block below a trust score, lengthen the undo window below a score, or accept only registered operators.
    /// </remarks>
    public Task<MerchantRules> GetMerchantRules(RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/merchant/rules"),
            [],
            [],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<MerchantRules>(),
            RawErrorResponse.Instance,
            [],
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Stream the store's activity
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="ActivityFeed"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="RawError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Every step Undo records, newest first (up to 60). Pass <c>after</c> to get only events newer than that id.
    /// </remarks>
    public Task<ActivityFeed> ListMerchantActivity(ListMerchantActivityRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/merchant/activity"),
            [],
            [new Param("after", request.After)],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<ActivityFeed>(),
            RawErrorResponse.Instance,
            [],
            requestOptions,
            cancellationToken);

    /// <summary>
    /// List agents and their trust scores
    /// </summary>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="MerchantAgents"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="RawError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Every agent that has shopped here, its record and trust score with every point explained, and what the store's rules do to it.
    /// </remarks>
    public Task<MerchantAgents> ListMerchantAgents(RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/merchant/agents"),
            [],
            [],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<MerchantAgents>(),
            RawErrorResponse.Instance,
            [],
            requestOptions,
            cancellationToken);

    /// <summary>
    /// List agent orders
    /// </summary>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="MerchantOrders"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="RawError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Every agent order (latest 300) with its verdict, who pays and any agent payout, plus headline numbers.
    /// </remarks>
    public Task<MerchantOrders> ListMerchantOrders(RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/merchant/orders"),
            [],
            [],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<MerchantOrders>(),
            RawErrorResponse.Instance,
            [],
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Resolve an order as the merchant
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="ResolveOrderResult"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="ResolveOrderError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// The merchant's side of an Undo. Sandbox only.
    /// </remarks>
    public Task<ResolveOrderResult> ResolveOrder(ResolveOrderOperationRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/orders/{orderId}/resolve"),
            [new TemplateParam("orderId", request.OrderId)],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Post,
            JsonRequest.Create(request.Body),
            JsonResponse.Create<ResolveOrderResult>(),
            ResolveOrderError.Response,
            [],
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Update the store's agent rules
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="MerchantRules"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="UpdateMerchantRulesError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Applies from the next checkout, for Undo's agent and every MCP agent. Each change is recorded in the store's event chain.
    /// </remarks>
    public Task<MerchantRules> UpdateMerchantRules(UpdateMerchantRulesRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/merchant/rules"),
            [],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Put,
            JsonRequest.Create(request.Body),
            JsonResponse.Create<MerchantRules>(),
            UpdateMerchantRulesError.Response,
            [],
            requestOptions,
            cancellationToken);
}
