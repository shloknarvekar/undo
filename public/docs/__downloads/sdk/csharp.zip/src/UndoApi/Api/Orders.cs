using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using UndoApi.Core;
using UndoApi.Core.Exceptions;
using UndoApi.Core.Models;
using UndoApi.Core.Request;
using UndoApi.Core.Response;
using UndoApi.Errors;
using UndoApi.Models;
using UndoApi.Requests.Orders;

namespace UndoApi.Api;

/// <summary>
/// Purchases, their undo windows, the Undo button, and the evidence to verify them.
/// </summary>
public sealed class Orders
{
    private readonly RawClient _rawClient;
    private readonly Server _server;

    internal Orders(RawClient rawClient, Server server)
    {
        _rawClient = rawClient;
        _server = server;
    }

    /// <summary>
    /// Get an order
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="OrderView"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="GetOrderError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// The purchase, the live undo window, the mandate behind it, and its verified event chain. Each event carries its proof.
    /// </remarks>
    public Task<OrderView> GetOrder(GetOrderRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/orders/{orderId}"),
            [new TemplateParam("orderId", request.OrderId)],
            [],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<OrderView>(),
            GetOrderError.Response,
            [],
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Download the evidence for an order
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="Evidence"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="GetOrderEvidenceError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Everything needed to check an order without trusting Undo: the raw hash-chained events exactly as hashed and
    /// the signed mandate exactly as stored. Nothing is pre-verified, on purpose.
    /// </remarks>
    public Task<Evidence> GetOrderEvidence(GetOrderEvidenceRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/orders/{orderId}/evidence"),
            [new TemplateParam("orderId", request.OrderId)],
            [],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<Evidence>(),
            GetOrderEvidenceError.Response,
            [],
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Undo a purchase
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="UndoResult"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="UndoOrderError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// The Undo button. Must be signed by the mandate's shopper key over
    /// <c>undo-request-v1:&lt;orderId&gt;:&lt;sha256 hex of reason&gt;:&lt;sha256 hex of photo bytes, or -&gt;:&lt;requestedAt&gt;</c>.
    /// <c>requestedAt</c> must be within 15 minutes of now. Runs the fault check, then routes the money: a void inside
    /// the window, or a refund, merchant claim, return or human review after capture. Rate limited per visitor.
    /// </remarks>
    public Task<UndoResult> UndoOrder(UndoOrderRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/orders/{orderId}/undo"),
            [new TemplateParam("orderId", request.OrderId)],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Post,
            JsonRequest.Create(request.Body),
            JsonResponse.Create<UndoResult>(),
            UndoOrderError.Response,
            [],
            requestOptions,
            cancellationToken);
}
