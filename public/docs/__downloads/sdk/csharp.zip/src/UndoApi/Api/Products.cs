using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using UndoApi.Core;
using UndoApi.Core.Exceptions;
using UndoApi.Core.Models;
using UndoApi.Core.Request;
using UndoApi.Core.Response;
using UndoApi.Errors;
using UndoApi.Models;
using UndoApi.Requests.Products;

namespace UndoApi.Api;

/// <summary>
/// Live product catalog search and detail, resolved to an exact variant.
/// </summary>
public sealed class Products
{
    private readonly RawClient _rawClient;
    private readonly Server _server;

    internal Products(RawClient rawClient, Server server)
    {
        _rawClient = rawClient;
        _server = server;
    }

    /// <summary>
    /// Get a product at a variant
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="ProductDetail"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="GetProductError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Fresh product detail resolved to the requested variant. Pass options as <c>option_&lt;Name&gt;=&lt;value&gt;</c> query
    /// parameters, for example <c>option_Size=M&amp;option_Color=Black</c>. <c>relaxed</c> lists any option the catalog could not honor.
    /// </remarks>
    public Task<ProductDetail> GetProduct(GetProductRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/products/{productId}"),
            [new TemplateParam("productId", request.ProductId)],
            [new Param("options", request.Options)],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<ProductDetail>(),
            GetProductError.Response,
            [],
            requestOptions,
            cancellationToken);

    /// <summary>
    /// Search products
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="ProductSearchResult"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="SearchProductsError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Searches the live catalog with structured filters. Rate limited per visitor.
    /// </remarks>
    public Task<ProductSearchResult> SearchProducts(SearchProductsRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/products/search"),
            [],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Post,
            JsonRequest.Create(request.Body),
            JsonResponse.Create<ProductSearchResult>(),
            SearchProductsError.Response,
            [],
            requestOptions,
            cancellationToken);
}
