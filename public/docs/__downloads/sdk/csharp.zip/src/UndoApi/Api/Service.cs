using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using UndoApi.Core;
using UndoApi.Core.Exceptions;
using UndoApi.Core.Models;
using UndoApi.Core.Request;
using UndoApi.Core.Response;
using UndoApi.Errors;
using UndoApi.Models;
using UndoApi.Requests.Service;

namespace UndoApi.Api;

/// <summary>
/// Health and deploy checks.
/// </summary>
public sealed class Service
{
    private readonly RawClient _rawClient;
    private readonly Server _server;

    internal Service(RawClient rawClient, Server server)
    {
        _rawClient = rawClient;
        _server = server;
    }

    /// <summary>
    /// Check the service
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="Health"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="GetHealthError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Shallow health check. With <c>deep</c>, also proves the service can reach PayPal sandbox and the database. Never returns secret values.
    /// </remarks>
    public Task<Health> GetHealth(GetHealthRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/health"),
            [],
            [new Param("deep", request.Deep)],
            [],
            HttpMethod.Get,
            EmptyBody.Instance,
            JsonResponse.Create<Health>(),
            GetHealthError.Response,
            [],
            requestOptions,
            cancellationToken);
}
