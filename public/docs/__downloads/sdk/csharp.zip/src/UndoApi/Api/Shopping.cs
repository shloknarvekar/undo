using System;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using UndoApi.Core;
using UndoApi.Core.Exceptions;
using UndoApi.Core.Models;
using UndoApi.Core.Request;
using UndoApi.Core.Response;
using UndoApi.Errors;
using UndoApi.Models;
using UndoApi.Requests.Shopping;

namespace UndoApi.Api;

/// <summary>
/// Let Undo's agent shop inside a mandate and open a PayPal checkout that only authorizes the money.
/// </summary>
public sealed class Shopping
{
    private readonly RawClient _rawClient;
    private readonly Server _server;

    internal Shopping(RawClient rawClient, Server server)
    {
        _rawClient = rawClient;
        _server = server;
    }

    /// <summary>
    /// Shop inside a mandate
    /// </summary>
    /// <param name="request">The operation's inputs</param>
    /// <param name="requestOptions">Per-request options, such as an overriding log level for this call</param>
    /// <param name="cancellationToken">Cancellation token</param>
    /// <returns>A <see cref="Task{TResult}"/> of <see cref="ShopResult"/> instance.</returns>
    /// <exception cref="ApiException{TError}"> of <see cref="ShopMandateError"/> when the server returns an error response.</exception>
    /// <remarks>
    /// Undo's agent searches, checks the cart against the signed limits, and opens a PayPal checkout in AUTHORIZE
    /// mode. Without a saved wallet the shopper approves at <c>approveUrl</c>; with one (and only if the mandate allows it)
    /// the money is held straight away. One live purchase per mandate. Rate limited per visitor.
    /// </remarks>
    public Task<ShopResult> ShopMandate(ShopMandateOperationRequest request,
        RequestOptions? requestOptions = null,
        CancellationToken cancellationToken = default) =>
        _rawClient.Execute(
            _server.Default("/api/mandates/{mandateId}/shop"),
            [new TemplateParam("mandateId", request.MandateId)],
            [],
            [new HeaderParam("Idempotency-Key", Guid.NewGuid())],
            HttpMethod.Post,
            JsonRequest.Create(request.Body),
            JsonResponse.Create<ShopResult>(),
            ShopMandateError.Response,
            [],
            requestOptions,
            cancellationToken);
}
