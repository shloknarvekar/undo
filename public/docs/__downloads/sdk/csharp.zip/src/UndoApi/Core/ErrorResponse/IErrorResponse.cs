using System.Threading;
using System.Threading.Tasks;
using UndoApi.Core.Models;

namespace UndoApi.Core.ErrorResponse;

internal interface IErrorResponse<TError>
{
    Task<TError> Map(ResponseContext context, CancellationToken cancellationToken);
}