using System.Collections.Generic;
using Microsoft.Extensions.Logging;
using UndoApi.Core.Hooks;

namespace UndoApi.Core;

public sealed record RequestOptions
{
    public LogLevel? LogLevel { get; init; }

    public IReadOnlyList<SdkHook>? Hooks { get; init; }
}
