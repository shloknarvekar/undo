using System.Threading.Tasks;
using UndoApi.Core.ErrorResponse;
using UndoApi.Core.Models;
using UndoApi.Models;

namespace UndoApi.Errors;

public sealed class DraftMandateError : ApiError
{
    private readonly Optional<Error> _errorValue;

    private readonly Optional<RateLimited> _rateLimitedValue;

    private DraftMandateError(Optional<Error> errorValue,
        Optional<RateLimited> rateLimitedValue,
        Optional<RawError> fallback) : base(fallback)
    {
        _errorValue = errorValue;
        _rateLimitedValue = rateLimitedValue;
    }

    private static DraftMandateError AsError(Error value) => new(Optional<Error>.Some(value), default, default);

    private static DraftMandateError AsRateLimited(RateLimited value) =>
        new(default, Optional<RateLimited>.Some(value), default);

    private static DraftMandateError AsFallback(RawError value) =>
        new(default, default, Optional<RawError>.Some(value));

    public bool TryGetError(out Error value) => _errorValue.TryGetValue(out value);

    public bool TryGetRateLimited(out RateLimited value) => _rateLimitedValue.TryGetValue(out value);

    private static Task<DraftMandateError> Create(FailedResponse response) =>
        response.StatusCode switch
        {
            400 or 502 or 503 => response.Json<Error>().As(AsError),
            429 => response.Json<RateLimited>().As(AsRateLimited),
            _ => response.RawBody().As(AsFallback)
        };

    internal static ApiErrorResponse<DraftMandateError> Response { get; } = new(Create);
}
