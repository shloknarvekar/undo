using System.Threading.Tasks;
using UndoApi.Core.ErrorResponse;
using UndoApi.Core.Models;
using UndoApi.Models;

namespace UndoApi.Errors;

public sealed class GetHealthError : ApiError
{
    private readonly Optional<Health> _healthValue;

    private GetHealthError(Optional<Health> healthValue, Optional<RawError> fallback) : base(fallback)
    {
        _healthValue = healthValue;
    }

    private static GetHealthError AsHealth(Health value) => new(Optional<Health>.Some(value), default);

    private static GetHealthError AsFallback(RawError value) => new(default, Optional<RawError>.Some(value));

    public bool TryGetHealth(out Health value) => _healthValue.TryGetValue(out value);

    private static Task<GetHealthError> Create(FailedResponse response) =>
        response.StatusCode switch
        {
            503 => response.Json<Health>().As(AsHealth),
            _ => response.RawBody().As(AsFallback)
        };

    internal static ApiErrorResponse<GetHealthError> Response { get; } = new(Create);
}
