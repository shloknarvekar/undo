using System.Threading.Tasks;
using UndoApi.Core.ErrorResponse;
using UndoApi.Core.Models;
using UndoApi.Models;

namespace UndoApi.Errors;

public sealed class GetOrderError : ApiError
{
    private readonly Optional<Error> _errorValue;

    private GetOrderError(Optional<Error> errorValue, Optional<RawError> fallback) : base(fallback)
    {
        _errorValue = errorValue;
    }

    private static GetOrderError AsError(Error value) => new(Optional<Error>.Some(value), default);

    private static GetOrderError AsFallback(RawError value) => new(default, Optional<RawError>.Some(value));

    public bool TryGetError(out Error value) => _errorValue.TryGetValue(out value);

    private static Task<GetOrderError> Create(FailedResponse response) =>
        response.StatusCode switch
        {
            404 => response.Json<Error>().As(AsError),
            _ => response.RawBody().As(AsFallback)
        };

    internal static ApiErrorResponse<GetOrderError> Response { get; } = new(Create);
}
