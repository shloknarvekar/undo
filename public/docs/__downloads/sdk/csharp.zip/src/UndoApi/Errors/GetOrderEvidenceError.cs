using System.Threading.Tasks;
using UndoApi.Core.ErrorResponse;
using UndoApi.Core.Models;
using UndoApi.Models;

namespace UndoApi.Errors;

public sealed class GetOrderEvidenceError : ApiError
{
    private readonly Optional<Error> _errorValue;

    private GetOrderEvidenceError(Optional<Error> errorValue, Optional<RawError> fallback) : base(fallback)
    {
        _errorValue = errorValue;
    }

    private static GetOrderEvidenceError AsError(Error value) => new(Optional<Error>.Some(value), default);

    private static GetOrderEvidenceError AsFallback(RawError value) => new(default, Optional<RawError>.Some(value));

    public bool TryGetError(out Error value) => _errorValue.TryGetValue(out value);

    private static Task<GetOrderEvidenceError> Create(FailedResponse response) =>
        response.StatusCode switch
        {
            404 => response.Json<Error>().As(AsError),
            _ => response.RawBody().As(AsFallback)
        };

    internal static ApiErrorResponse<GetOrderEvidenceError> Response { get; } = new(Create);
}
