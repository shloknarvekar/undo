using System.Threading.Tasks;
using UndoApi.Core.ErrorResponse;
using UndoApi.Core.Models;
using UndoApi.Models;

namespace UndoApi.Errors;

public sealed class GetProductError : ApiError
{
    private readonly Optional<Error> _errorValue;

    private GetProductError(Optional<Error> errorValue, Optional<RawError> fallback) : base(fallback)
    {
        _errorValue = errorValue;
    }

    private static GetProductError AsError(Error value) => new(Optional<Error>.Some(value), default);

    private static GetProductError AsFallback(RawError value) => new(default, Optional<RawError>.Some(value));

    public bool TryGetError(out Error value) => _errorValue.TryGetValue(out value);

    private static Task<GetProductError> Create(FailedResponse response) =>
        response.StatusCode switch
        {
            404 or 502 => response.Json<Error>().As(AsError),
            _ => response.RawBody().As(AsFallback)
        };

    internal static ApiErrorResponse<GetProductError> Response { get; } = new(Create);
}
