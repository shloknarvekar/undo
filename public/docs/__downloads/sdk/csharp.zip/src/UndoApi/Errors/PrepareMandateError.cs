using System.Threading.Tasks;
using UndoApi.Core.ErrorResponse;
using UndoApi.Core.Models;
using UndoApi.Models;

namespace UndoApi.Errors;

public sealed class PrepareMandateError : ApiError
{
    private readonly Optional<Error> _errorValue;

    private readonly Optional<NotReady> _notReadyValue;

    private PrepareMandateError(Optional<Error> errorValue,
        Optional<NotReady> notReadyValue,
        Optional<RawError> fallback) : base(fallback)
    {
        _errorValue = errorValue;
        _notReadyValue = notReadyValue;
    }

    private static PrepareMandateError AsError(Error value) => new(Optional<Error>.Some(value), default, default);

    private static PrepareMandateError AsNotReady(NotReady value) =>
        new(default, Optional<NotReady>.Some(value), default);

    private static PrepareMandateError AsFallback(RawError value) =>
        new(default, default, Optional<RawError>.Some(value));

    public bool TryGetError(out Error value) => _errorValue.TryGetValue(out value);

    public bool TryGetNotReady(out NotReady value) => _notReadyValue.TryGetValue(out value);

    private static Task<PrepareMandateError> Create(FailedResponse response) =>
        response.StatusCode switch
        {
            400 => response.Json<Error>().As(AsError),
            422 => response.Json<NotReady>().As(AsNotReady),
            _ => response.RawBody().As(AsFallback)
        };

    internal static ApiErrorResponse<PrepareMandateError> Response { get; } = new(Create);
}
