using System.Threading.Tasks;
using UndoApi.Core.ErrorResponse;
using UndoApi.Core.Models;
using UndoApi.Models;

namespace UndoApi.Errors;

public sealed class ResolveOrderError : ApiError
{
    private readonly Optional<Error> _errorValue;

    private ResolveOrderError(Optional<Error> errorValue, Optional<RawError> fallback) : base(fallback)
    {
        _errorValue = errorValue;
    }

    private static ResolveOrderError AsError(Error value) => new(Optional<Error>.Some(value), default);

    private static ResolveOrderError AsFallback(RawError value) => new(default, Optional<RawError>.Some(value));

    public bool TryGetError(out Error value) => _errorValue.TryGetValue(out value);

    private static Task<ResolveOrderError> Create(FailedResponse response) =>
        response.StatusCode switch
        {
            400 or 403 or 404 or 409 or 502 => response.Json<Error>().As(AsError),
            _ => response.RawBody().As(AsFallback)
        };

    internal static ApiErrorResponse<ResolveOrderError> Response { get; } = new(Create);
}
