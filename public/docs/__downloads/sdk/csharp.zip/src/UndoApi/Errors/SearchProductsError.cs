using System.Threading.Tasks;
using UndoApi.Core.ErrorResponse;
using UndoApi.Core.Models;
using UndoApi.Models;

namespace UndoApi.Errors;

public sealed class SearchProductsError : ApiError
{
    private readonly Optional<Error> _errorValue;

    private readonly Optional<RateLimited> _rateLimitedValue;

    private SearchProductsError(Optional<Error> errorValue,
        Optional<RateLimited> rateLimitedValue,
        Optional<RawError> fallback) : base(fallback)
    {
        _errorValue = errorValue;
        _rateLimitedValue = rateLimitedValue;
    }

    private static SearchProductsError AsError(Error value) => new(Optional<Error>.Some(value), default, default);

    private static SearchProductsError AsRateLimited(RateLimited value) =>
        new(default, Optional<RateLimited>.Some(value), default);

    private static SearchProductsError AsFallback(RawError value) =>
        new(default, default, Optional<RawError>.Some(value));

    public bool TryGetError(out Error value) => _errorValue.TryGetValue(out value);

    public bool TryGetRateLimited(out RateLimited value) => _rateLimitedValue.TryGetValue(out value);

    private static Task<SearchProductsError> Create(FailedResponse response) =>
        response.StatusCode switch
        {
            400 or 502 => response.Json<Error>().As(AsError),
            429 => response.Json<RateLimited>().As(AsRateLimited),
            _ => response.RawBody().As(AsFallback)
        };

    internal static ApiErrorResponse<SearchProductsError> Response { get; } = new(Create);
}
