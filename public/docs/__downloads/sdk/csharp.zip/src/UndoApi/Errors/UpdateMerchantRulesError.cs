using System.Threading.Tasks;
using UndoApi.Core.ErrorResponse;
using UndoApi.Core.Models;
using UndoApi.Models;

namespace UndoApi.Errors;

public sealed class UpdateMerchantRulesError : ApiError
{
    private readonly Optional<Error> _errorValue;

    private readonly Optional<RateLimited> _rateLimitedValue;

    private UpdateMerchantRulesError(Optional<Error> errorValue,
        Optional<RateLimited> rateLimitedValue,
        Optional<RawError> fallback) : base(fallback)
    {
        _errorValue = errorValue;
        _rateLimitedValue = rateLimitedValue;
    }

    private static UpdateMerchantRulesError AsError(Error value) => new(Optional<Error>.Some(value), default, default);

    private static UpdateMerchantRulesError AsRateLimited(RateLimited value) =>
        new(default, Optional<RateLimited>.Some(value), default);

    private static UpdateMerchantRulesError AsFallback(RawError value) =>
        new(default, default, Optional<RawError>.Some(value));

    public bool TryGetError(out Error value) => _errorValue.TryGetValue(out value);

    public bool TryGetRateLimited(out RateLimited value) => _rateLimitedValue.TryGetValue(out value);

    private static Task<UpdateMerchantRulesError> Create(FailedResponse response) =>
        response.StatusCode switch
        {
            400 => response.Json<Error>().As(AsError),
            429 => response.Json<RateLimited>().As(AsRateLimited),
            _ => response.RawBody().As(AsFallback)
        };

    internal static ApiErrorResponse<UpdateMerchantRulesError> Response { get; } = new(Create);
}
