using System.Collections.Generic;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// The store's latest activity.
/// </summary>
public record ActivityFeed
{
    /// <summary>
    /// Events, newest first.
    /// </summary>
    [JsonPropertyName("events")]
    public required IReadOnlyList<ActivityEvent> Events { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
