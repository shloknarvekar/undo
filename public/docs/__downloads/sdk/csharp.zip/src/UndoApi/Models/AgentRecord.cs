using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// An agent's record at this store and what the rules do to it.
/// </summary>
public record AgentRecord
{
    /// <summary>
    /// The agent operator's name.
    /// </summary>
    [JsonPropertyName("name")]
    public required string Name { get; init; }

    /// <summary>
    /// Whether the agent presented a registered operator key.
    /// </summary>
    [JsonPropertyName("verified")]
    public required bool Verified { get; init; }

    /// <summary>
    /// How the agent connected: web or mcp.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("via")]
    public string? Via { get; init; }

    /// <summary>
    /// Purchases made at this store.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("purchases")]
    public int? Purchases { get; init; }

    /// <summary>
    /// Undos where the agent was at fault.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("faults")]
    public int? Faults { get; init; }

    /// <summary>
    /// An agent's trust score at this store, with every point explained.
    /// </summary>
    [JsonPropertyName("trust")]
    public required Trust Trust { get; init; }

    /// <summary>
    /// What the store's rules do to this agent's next purchase.
    /// </summary>
    [JsonPropertyName("effect")]
    public required RuleEffect Effect { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
