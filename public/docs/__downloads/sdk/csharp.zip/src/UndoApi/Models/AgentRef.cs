using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// The agent a mandate authorizes. Inside the signed bytes, so liability follows the name.
/// </summary>
public record AgentRef
{
    /// <summary>
    /// The agent's name as it introduced itself.
    /// </summary>
    [JsonPropertyName("name")]
    [MaxLength(80)]
    public required string Name { get; init; }

    /// <summary>
    /// The agent presented a registered operator key.
    /// </summary>
    [JsonPropertyName("verified")]
    public required bool Verified { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
