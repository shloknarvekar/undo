using System.Collections.Generic;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// Answer the agent's open questions.
/// </summary>
public record AnswerAction
{
    /// <summary>
    /// Always answer.
    /// </summary>
    [JsonPropertyName("action")]
    public string Action { get; } = "answer";

    /// <summary>
    /// Each open question (exactly as asked) mapped to the shopper's answer.
    /// </summary>
    [JsonPropertyName("answers")]
    public required IReadOnlyDictionary<string, string> Answers { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
