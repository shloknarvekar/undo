using System;
using System.Text.Json;
using System.Text.Json.Serialization;
using UndoApi.Core.Extensions;
using UndoApi.Core.Models;

namespace UndoApi.Models.AnyOf;

/// <summary>
/// The new draft after answer, or the mandate to sign after prepare.
/// </summary>
[JsonConverter(typeof(MandateRequestActionResultConverter))]
public record MandateRequestActionResult
{
    private readonly Optional<DraftResult> _draftResultValue;

    private readonly Optional<PreparedMandate> _preparedMandateValue;

    private MandateRequestActionResult(Optional<DraftResult> draftResultValue,
        Optional<PreparedMandate> preparedMandateValue)
    {
        _draftResultValue = draftResultValue;
        _preparedMandateValue = preparedMandateValue;
    }

    public static MandateRequestActionResult DraftResult(DraftResult value) =>
        new(Optional<DraftResult>.Some(value), default);

    public static MandateRequestActionResult PreparedMandate(PreparedMandate value) =>
        new(default, Optional<PreparedMandate>.Some(value));

    public bool TryGetDraftResult(out DraftResult value) => _draftResultValue.TryGetValue(out value);

    public bool TryGetPreparedMandate(out PreparedMandate value) => _preparedMandateValue.TryGetValue(out value);

    public static implicit operator MandateRequestActionResult(DraftResult value) => DraftResult(value);

    public static implicit operator MandateRequestActionResult(PreparedMandate value) => PreparedMandate(value);
}

file sealed class MandateRequestActionResultConverter : JsonConverter<MandateRequestActionResult>
{
    public override MandateRequestActionResult Read(ref Utf8JsonReader reader,
        Type typeToConvert,
        JsonSerializerOptions options)
    {
        using var doc = JsonDocument.ParseValue(ref reader);
        var root = doc.RootElement;
        if (JsonSerializer.TryDeserialize<DraftResult>(root, options, out var draftResultValue))
        {
            return MandateRequestActionResult.DraftResult(draftResultValue);
        }
        if (JsonSerializer.TryDeserialize<PreparedMandate>(root, options, out var preparedMandateValue))
        {
            return MandateRequestActionResult.PreparedMandate(preparedMandateValue);
        }
        throw new JsonException($"JSON does not match DraftResult or PreparedMandate schemas: {root.ToString()}");
    }

    public override void Write(Utf8JsonWriter writer, MandateRequestActionResult value, JsonSerializerOptions options)
    {
        if (value.TryGetDraftResult(out var draftResultValue))
        {
            JsonSerializer.Serialize(writer, draftResultValue, options);
        }
        else if (value.TryGetPreparedMandate(out var preparedMandateValue))
        {
            JsonSerializer.Serialize(writer, preparedMandateValue, options);
        }
        else
        {
            throw new JsonException($"{nameof(MandateRequestActionResult)} contains no valid value to serialize.");
        }
    }
}
