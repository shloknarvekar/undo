using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// One event in the hash chain, with the proof of how it was decided.
/// </summary>
public record ChainEvent
{
    /// <summary>
    /// Position in the hash chain, starting at 0.
    /// </summary>
    [JsonPropertyName("seq")]
    public required int Seq { get; init; }

    /// <summary>
    /// Event type, for example MANDATE_SIGNED or PAYMENT_VOIDED.
    /// </summary>
    [JsonPropertyName("type")]
    public required string Type { get; init; }

    /// <summary>
    /// When it was created (ISO 8601, UTC).
    /// </summary>
    [JsonPropertyName("createdAt")]
    public required DateTimeOffset CreatedAt { get; init; }

    /// <summary>
    /// SHA-256 of this event chained to the previous event's hash.
    /// </summary>
    [JsonPropertyName("hash")]
    public required string Hash { get; init; }

    /// <summary>
    /// How this step was decided, and the PayPal call or id behind it.
    /// </summary>
    [JsonPropertyName("proof")]
    public required object Proof { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
