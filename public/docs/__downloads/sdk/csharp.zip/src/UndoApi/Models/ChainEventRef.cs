using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// The first event in the mandate's hash chain (MANDATE_SIGNED).
/// </summary>
public record ChainEventRef
{
    /// <summary>
    /// Position in the hash chain, starting at 0.
    /// </summary>
    [JsonPropertyName("seq")]
    public required int Seq { get; init; }

    /// <summary>
    /// SHA-256 of this event chained to the previous event's hash.
    /// </summary>
    [JsonPropertyName("hash")]
    public required string Hash { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
