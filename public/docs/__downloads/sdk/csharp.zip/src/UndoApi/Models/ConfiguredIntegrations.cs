using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// Which integrations have credentials set. Never the values.
/// </summary>
public record ConfiguredIntegrations
{
    /// <summary>
    /// PayPal sandbox client id and secret are set.
    /// </summary>
    [JsonPropertyName("paypal")]
    public required bool Paypal { get; init; }

    /// <summary>
    /// The product catalog key is set.
    /// </summary>
    [JsonPropertyName("channel3")]
    public required bool Channel3 { get; init; }

    /// <summary>
    /// The Postgres connection string is set.
    /// </summary>
    [JsonPropertyName("database")]
    public required bool Database { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
