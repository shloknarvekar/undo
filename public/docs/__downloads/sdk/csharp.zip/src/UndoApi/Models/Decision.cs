using System.Collections.Generic;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;
using UndoApi.Core.Validation.Attributes;
using UndoApi.Models.Enums;

namespace UndoApi.Models;

/// <summary>
/// The fault check's verdict, who pays, and the evidence behind it.
/// </summary>
public record Decision
{
    /// <summary>
    /// Who was at fault.
    /// </summary>
    [JsonPropertyName("verdict")]
    public required Verdict Verdict { get; init; }

    /// <summary>
    /// How sure the fault check is, from 0 to 1. Below 0.7 goes to a person.
    /// </summary>
    [JsonPropertyName("confidence")]
    [Minimum(0.0)]
    [Maximum(1.0)]
    public required double Confidence { get; init; }

    /// <summary>
    /// Who pays. Null when a person still has to decide.
    /// </summary>
    [JsonPropertyName("liability")]
    public required Liability? Liability { get; init; }

    /// <summary>
    /// Each finding behind the verdict and where it came from.
    /// </summary>
    [JsonPropertyName("evidence")]
    public required IReadOnlyList<EvidenceItem> Evidence { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
