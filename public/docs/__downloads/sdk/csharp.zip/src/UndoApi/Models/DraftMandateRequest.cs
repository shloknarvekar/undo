using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// The shopper's words to turn into a draft.
/// </summary>
public record DraftMandateRequest
{
    /// <summary>
    /// The shopper's own words.
    /// </summary>
    [JsonPropertyName("request")]
    [StringLength(1000, MinimumLength = 3)]
    public required string Request { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
