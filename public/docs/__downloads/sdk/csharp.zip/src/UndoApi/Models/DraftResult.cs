using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// A structured draft of the shopper's limits, ready for review.
/// </summary>
public record DraftResult
{
    /// <summary>
    /// The request text, when it was extended with answers.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("request")]
    public string? Request { get; init; }

    /// <summary>
    /// The shopper's limits in structured form.
    /// </summary>
    [JsonPropertyName("draft")]
    public required IntentDraft Draft { get; init; }

    /// <summary>
    /// Whether a draft can be signed as is.
    /// </summary>
    [JsonPropertyName("ready")]
    public required ReadyCheck Ready { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
