using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Enum;

namespace UndoApi.Models.Enums;

/// <summary>
/// Always answer.
/// </summary>
[JsonConverter(typeof(StringEnumConverter<AnswerActionName>))]
public sealed record AnswerActionName : OpenStringEnum<AnswerActionName>
{
    private AnswerActionName(string value) : base(value)
    {
    }

    public static readonly AnswerActionName Answer = new("answer");

    public TResult Match<TResult>(Func<TResult> onAnswer, Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == Answer => onAnswer(),
            _ => otherwise(Value)
        };

    public void Match(Action onAnswer, Action<string> otherwise)
    {
        if (this == Answer) onAnswer();
        else otherwise(Value);
    }
}
