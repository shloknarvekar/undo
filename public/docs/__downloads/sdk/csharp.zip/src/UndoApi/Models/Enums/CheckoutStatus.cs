using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Enum;

namespace UndoApi.Models.Enums;

/// <summary>
/// Where a new checkout stands.
/// </summary>
[JsonConverter(typeof(StringEnumConverter<CheckoutStatus>))]
public sealed record CheckoutStatus : OpenStringEnum<CheckoutStatus>
{
    private CheckoutStatus(string value) : base(value)
    {
    }

    public static readonly CheckoutStatus CheckoutCreated = new("CHECKOUT_CREATED");

    public static readonly CheckoutStatus Authorized = new("AUTHORIZED");

    public TResult Match<TResult>(Func<TResult> onCheckoutCreated,
        Func<TResult> onAuthorized,
        Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == CheckoutCreated => onCheckoutCreated(),
            _ when this == Authorized => onAuthorized(),
            _ => otherwise(Value)
        };

    public void Match(Action onCheckoutCreated, Action onAuthorized, Action<string> otherwise)
    {
        if (this == CheckoutCreated) onCheckoutCreated();
        else if (this == Authorized) onAuthorized();
        else otherwise(Value);
    }
}
