using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Enum;

namespace UndoApi.Models.Enums;

/// <summary>
/// Evidence file format.
/// </summary>
[JsonConverter(typeof(StringEnumConverter<EvidenceFormat>))]
public sealed record EvidenceFormat : OpenStringEnum<EvidenceFormat>
{
    private EvidenceFormat(string value) : base(value)
    {
    }

    public static readonly EvidenceFormat UndoEvidenceV1 = new("undo-evidence-v1");

    public TResult Match<TResult>(Func<TResult> onUndoEvidenceV1, Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == UndoEvidenceV1 => onUndoEvidenceV1(),
            _ => otherwise(Value)
        };

    public void Match(Action onUndoEvidenceV1, Action<string> otherwise)
    {
        if (this == UndoEvidenceV1) onUndoEvidenceV1();
        else otherwise(Value);
    }
}
