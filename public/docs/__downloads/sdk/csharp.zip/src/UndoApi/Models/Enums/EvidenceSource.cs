using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Enum;

namespace UndoApi.Models.Enums;

/// <summary>
/// Where a finding came from.
/// </summary>
[JsonConverter(typeof(StringEnumConverter<EvidenceSource>))]
public sealed record EvidenceSource : OpenStringEnum<EvidenceSource>
{
    private EvidenceSource(string value) : base(value)
    {
    }

    public static readonly EvidenceSource MandateCheck = new("mandate_check");

    public static readonly EvidenceSource AgentRecord = new("agent_record");

    public static readonly EvidenceSource DeliveredPhoto = new("delivered_photo");

    public static readonly EvidenceSource AiJudgement = new("ai_judgement");

    public static readonly EvidenceSource Shopper = new("shopper");

    public TResult Match<TResult>(Func<TResult> onMandateCheck,
        Func<TResult> onAgentRecord,
        Func<TResult> onDeliveredPhoto,
        Func<TResult> onAiJudgement,
        Func<TResult> onShopper,
        Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == MandateCheck => onMandateCheck(),
            _ when this == AgentRecord => onAgentRecord(),
            _ when this == DeliveredPhoto => onDeliveredPhoto(),
            _ when this == AiJudgement => onAiJudgement(),
            _ when this == Shopper => onShopper(),
            _ => otherwise(Value)
        };

    public void Match(Action onMandateCheck,
        Action onAgentRecord,
        Action onDeliveredPhoto,
        Action onAiJudgement,
        Action onShopper,
        Action<string> otherwise)
    {
        if (this == MandateCheck) onMandateCheck();
        else if (this == AgentRecord) onAgentRecord();
        else if (this == DeliveredPhoto) onDeliveredPhoto();
        else if (this == AiJudgement) onAiJudgement();
        else if (this == Shopper) onShopper();
        else otherwise(Value);
    }
}
