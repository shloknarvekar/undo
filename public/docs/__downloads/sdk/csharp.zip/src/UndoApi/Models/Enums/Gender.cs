using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Enum;

namespace UndoApi.Models.Enums;

/// <summary>
/// Men's or women's products.
/// </summary>
[JsonConverter(typeof(StringEnumConverter<Gender>))]
public sealed record Gender : OpenStringEnum<Gender>
{
    private Gender(string value) : base(value)
    {
    }

    public static readonly Gender Male = new("male");

    public static readonly Gender Female = new("female");

    public TResult Match<TResult>(Func<TResult> onMale, Func<TResult> onFemale, Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == Male => onMale(),
            _ when this == Female => onFemale(),
            _ => otherwise(Value)
        };

    public void Match(Action onMale, Action onFemale, Action<string> otherwise)
    {
        if (this == Male) onMale();
        else if (this == Female) onFemale();
        else otherwise(Value);
    }
}
