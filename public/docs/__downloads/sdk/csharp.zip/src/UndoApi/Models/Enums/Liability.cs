using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Enum;

namespace UndoApi.Models.Enums;

/// <summary>
/// Who pays. Null when a person still has to decide.
/// </summary>
[JsonConverter(typeof(StringEnumConverter<Liability>))]
public sealed record Liability : OpenStringEnum<Liability>
{
    private Liability(string value) : base(value)
    {
    }

    public static readonly Liability AgentOperator = new("agent_operator");

    public static readonly Liability Merchant = new("merchant");

    public static readonly Liability Shopper = new("shopper");

    public TResult Match<TResult>(Func<TResult> onAgentOperator,
        Func<TResult> onMerchant,
        Func<TResult> onShopper,
        Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == AgentOperator => onAgentOperator(),
            _ when this == Merchant => onMerchant(),
            _ when this == Shopper => onShopper(),
            _ => otherwise(Value)
        };

    public void Match(Action onAgentOperator, Action onMerchant, Action onShopper, Action<string> otherwise)
    {
        if (this == AgentOperator) onAgentOperator();
        else if (this == Merchant) onMerchant();
        else if (this == Shopper) onShopper();
        else otherwise(Value);
    }
}
