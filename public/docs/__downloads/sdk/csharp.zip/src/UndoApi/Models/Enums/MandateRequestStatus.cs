using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Enum;

namespace UndoApi.Models.Enums;

/// <summary>
/// Where a mandate request stands.
/// </summary>
[JsonConverter(typeof(StringEnumConverter<MandateRequestStatus>))]
public sealed record MandateRequestStatus : OpenStringEnum<MandateRequestStatus>
{
    private MandateRequestStatus(string value) : base(value)
    {
    }

    public static readonly MandateRequestStatus Pending = new("PENDING");

    public static readonly MandateRequestStatus Signed = new("SIGNED");

    public static readonly MandateRequestStatus Expired = new("EXPIRED");

    public TResult Match<TResult>(Func<TResult> onPending,
        Func<TResult> onSigned,
        Func<TResult> onExpired,
        Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == Pending => onPending(),
            _ when this == Signed => onSigned(),
            _ when this == Expired => onExpired(),
            _ => otherwise(Value)
        };

    public void Match(Action onPending, Action onSigned, Action onExpired, Action<string> otherwise)
    {
        if (this == Pending) onPending();
        else if (this == Signed) onSigned();
        else if (this == Expired) onExpired();
        else otherwise(Value);
    }
}
