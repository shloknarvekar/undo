using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Enum;

namespace UndoApi.Models.Enums;

/// <summary>
/// Where a mandate stands.
/// </summary>
[JsonConverter(typeof(StringEnumConverter<MandateStatus>))]
public sealed record MandateStatus : OpenStringEnum<MandateStatus>
{
    private MandateStatus(string value) : base(value)
    {
    }

    public static readonly MandateStatus Active = new("ACTIVE");

    public static readonly MandateStatus Fulfilled = new("FULFILLED");

    public static readonly MandateStatus Revoked = new("REVOKED");

    public static readonly MandateStatus Expired = new("EXPIRED");

    public TResult Match<TResult>(Func<TResult> onActive,
        Func<TResult> onFulfilled,
        Func<TResult> onRevoked,
        Func<TResult> onExpired,
        Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == Active => onActive(),
            _ when this == Fulfilled => onFulfilled(),
            _ when this == Revoked => onRevoked(),
            _ when this == Expired => onExpired(),
            _ => otherwise(Value)
        };

    public void Match(Action onActive, Action onFulfilled, Action onRevoked, Action onExpired, Action<string> otherwise)
    {
        if (this == Active) onActive();
        else if (this == Fulfilled) onFulfilled();
        else if (this == Revoked) onRevoked();
        else if (this == Expired) onExpired();
        else otherwise(Value);
    }
}
