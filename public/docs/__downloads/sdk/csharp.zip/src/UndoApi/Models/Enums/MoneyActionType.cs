using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Enum;

namespace UndoApi.Models.Enums;

/// <summary>
/// What happens to the money.
/// </summary>
[JsonConverter(typeof(StringEnumConverter<MoneyActionType>))]
public sealed record MoneyActionType : OpenStringEnum<MoneyActionType>
{
    private MoneyActionType(string value) : base(value)
    {
    }

    public static readonly MoneyActionType Void = new("VOID");

    public static readonly MoneyActionType RefundFull = new("REFUND_FULL");

    public static readonly MoneyActionType OpenClaim = new("OPEN_CLAIM");

    public static readonly MoneyActionType AuthorizeReturn = new("AUTHORIZE_RETURN");

    public static readonly MoneyActionType Review = new("REVIEW");

    public static readonly MoneyActionType None = new("NONE");

    public TResult Match<TResult>(Func<TResult> onVoid,
        Func<TResult> onRefundFull,
        Func<TResult> onOpenClaim,
        Func<TResult> onAuthorizeReturn,
        Func<TResult> onReview,
        Func<TResult> onNone,
        Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == Void => onVoid(),
            _ when this == RefundFull => onRefundFull(),
            _ when this == OpenClaim => onOpenClaim(),
            _ when this == AuthorizeReturn => onAuthorizeReturn(),
            _ when this == Review => onReview(),
            _ when this == None => onNone(),
            _ => otherwise(Value)
        };

    public void Match(Action onVoid,
        Action onRefundFull,
        Action onOpenClaim,
        Action onAuthorizeReturn,
        Action onReview,
        Action onNone,
        Action<string> otherwise)
    {
        if (this == Void) onVoid();
        else if (this == RefundFull) onRefundFull();
        else if (this == OpenClaim) onOpenClaim();
        else if (this == AuthorizeReturn) onAuthorizeReturn();
        else if (this == Review) onReview();
        else if (this == None) onNone();
        else otherwise(Value);
    }
}
