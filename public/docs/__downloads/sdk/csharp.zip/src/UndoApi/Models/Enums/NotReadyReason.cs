using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Enum;

namespace UndoApi.Models.Enums;

/// <summary>
/// Why a draft can't be signed yet.
/// </summary>
[JsonConverter(typeof(StringEnumConverter<NotReadyReason>))]
public sealed record NotReadyReason : OpenStringEnum<NotReadyReason>
{
    private NotReadyReason(string value) : base(value)
    {
    }

    public static readonly NotReadyReason OpenQuestions = new("open_questions");

    public static readonly NotReadyReason MissingBudget = new("missing_budget");

    public TResult Match<TResult>(Func<TResult> onOpenQuestions,
        Func<TResult> onMissingBudget,
        Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == OpenQuestions => onOpenQuestions(),
            _ when this == MissingBudget => onMissingBudget(),
            _ => otherwise(Value)
        };

    public void Match(Action onOpenQuestions, Action onMissingBudget, Action<string> otherwise)
    {
        if (this == OpenQuestions) onOpenQuestions();
        else if (this == MissingBudget) onMissingBudget();
        else otherwise(Value);
    }
}
