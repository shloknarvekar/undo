using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Enum;

namespace UndoApi.Models.Enums;

/// <summary>
/// Where an order stands. AUTHORIZED means the money is only held and Undo is a free void.
/// </summary>
[JsonConverter(typeof(StringEnumConverter<OrderStatus>))]
public sealed record OrderStatus : OpenStringEnum<OrderStatus>
{
    private OrderStatus(string value) : base(value)
    {
    }

    public static readonly OrderStatus CheckoutCreated = new("CHECKOUT_CREATED");

    public static readonly OrderStatus Cancelled = new("CANCELLED");

    public static readonly OrderStatus Authorized = new("AUTHORIZED");

    public static readonly OrderStatus Voided = new("VOIDED");

    public static readonly OrderStatus Captured = new("CAPTURED");

    public static readonly OrderStatus Refunded = new("REFUNDED");

    public static readonly OrderStatus PartiallyRefunded = new("PARTIALLY_REFUNDED");

    public static readonly OrderStatus ClaimOpen = new("CLAIM_OPEN");

    public static readonly OrderStatus ReturnPending = new("RETURN_PENDING");

    public static readonly OrderStatus Review = new("REVIEW");

    public static readonly OrderStatus Disputed = new("DISPUTED");

    public static readonly OrderStatus Failed = new("FAILED");

    public TResult Match<TResult>(Func<TResult> onCheckoutCreated,
        Func<TResult> onCancelled,
        Func<TResult> onAuthorized,
        Func<TResult> onVoided,
        Func<TResult> onCaptured,
        Func<TResult> onRefunded,
        Func<TResult> onPartiallyRefunded,
        Func<TResult> onClaimOpen,
        Func<TResult> onReturnPending,
        Func<TResult> onReview,
        Func<TResult> onDisputed,
        Func<TResult> onFailed,
        Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == CheckoutCreated => onCheckoutCreated(),
            _ when this == Cancelled => onCancelled(),
            _ when this == Authorized => onAuthorized(),
            _ when this == Voided => onVoided(),
            _ when this == Captured => onCaptured(),
            _ when this == Refunded => onRefunded(),
            _ when this == PartiallyRefunded => onPartiallyRefunded(),
            _ when this == ClaimOpen => onClaimOpen(),
            _ when this == ReturnPending => onReturnPending(),
            _ when this == Review => onReview(),
            _ when this == Disputed => onDisputed(),
            _ when this == Failed => onFailed(),
            _ => otherwise(Value)
        };

    public void Match(Action onCheckoutCreated,
        Action onCancelled,
        Action onAuthorized,
        Action onVoided,
        Action onCaptured,
        Action onRefunded,
        Action onPartiallyRefunded,
        Action onClaimOpen,
        Action onReturnPending,
        Action onReview,
        Action onDisputed,
        Action onFailed,
        Action<string> otherwise)
    {
        if (this == CheckoutCreated) onCheckoutCreated();
        else if (this == Cancelled) onCancelled();
        else if (this == Authorized) onAuthorized();
        else if (this == Voided) onVoided();
        else if (this == Captured) onCaptured();
        else if (this == Refunded) onRefunded();
        else if (this == PartiallyRefunded) onPartiallyRefunded();
        else if (this == ClaimOpen) onClaimOpen();
        else if (this == ReturnPending) onReturnPending();
        else if (this == Review) onReview();
        else if (this == Disputed) onDisputed();
        else if (this == Failed) onFailed();
        else otherwise(Value);
    }
}
