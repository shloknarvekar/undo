using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Enum;

namespace UndoApi.Models.Enums;

/// <summary>
/// How a purchase was paid.
/// </summary>
[JsonConverter(typeof(StringEnumConverter<PaidWith>))]
public sealed record PaidWith : OpenStringEnum<PaidWith>
{
    private PaidWith(string value) : base(value)
    {
    }

    public static readonly PaidWith Approval = new("approval");

    public static readonly PaidWith SavedWallet = new("saved_wallet");

    public TResult Match<TResult>(Func<TResult> onApproval,
        Func<TResult> onSavedWallet,
        Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == Approval => onApproval(),
            _ when this == SavedWallet => onSavedWallet(),
            _ => otherwise(Value)
        };

    public void Match(Action onApproval, Action onSavedWallet, Action<string> otherwise)
    {
        if (this == Approval) onApproval();
        else if (this == SavedWallet) onSavedWallet();
        else otherwise(Value);
    }
}
