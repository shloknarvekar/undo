using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Enum;

namespace UndoApi.Models.Enums;

/// <summary>
/// How the agent may pay.
/// </summary>
[JsonConverter(typeof(StringEnumConverter<PayWith>))]
public sealed record PayWith : OpenStringEnum<PayWith>
{
    private PayWith(string value) : base(value)
    {
    }

    public static readonly PayWith SavedWallet = new("saved_wallet");

    public TResult Match<TResult>(Func<TResult> onSavedWallet, Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == SavedWallet => onSavedWallet(),
            _ => otherwise(Value)
        };

    public void Match(Action onSavedWallet, Action<string> otherwise)
    {
        if (this == SavedWallet) onSavedWallet();
        else otherwise(Value);
    }
}
