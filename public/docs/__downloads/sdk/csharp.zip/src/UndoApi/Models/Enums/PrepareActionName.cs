using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Enum;

namespace UndoApi.Models.Enums;

/// <summary>
/// Always prepare.
/// </summary>
[JsonConverter(typeof(StringEnumConverter<PrepareActionName>))]
public sealed record PrepareActionName : OpenStringEnum<PrepareActionName>
{
    private PrepareActionName(string value) : base(value)
    {
    }

    public static readonly PrepareActionName Prepare = new("prepare");

    public TResult Match<TResult>(Func<TResult> onPrepare, Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == Prepare => onPrepare(),
            _ => otherwise(Value)
        };

    public void Match(Action onPrepare, Action<string> otherwise)
    {
        if (this == Prepare) onPrepare();
        else otherwise(Value);
    }
}
