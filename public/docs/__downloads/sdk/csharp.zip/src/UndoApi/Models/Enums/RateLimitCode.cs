using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Enum;

namespace UndoApi.Models.Enums;

/// <summary>
/// The error code on a 429.
/// </summary>
[JsonConverter(typeof(StringEnumConverter<RateLimitCode>))]
public sealed record RateLimitCode : OpenStringEnum<RateLimitCode>
{
    private RateLimitCode(string value) : base(value)
    {
    }

    public static readonly RateLimitCode RateLimited = new("rate_limited");

    public TResult Match<TResult>(Func<TResult> onRateLimited, Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == RateLimited => onRateLimited(),
            _ => otherwise(Value)
        };

    public void Match(Action onRateLimited, Action<string> otherwise)
    {
        if (this == RateLimited) onRateLimited();
        else otherwise(Value);
    }
}
