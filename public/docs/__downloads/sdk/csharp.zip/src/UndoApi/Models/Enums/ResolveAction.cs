using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Enum;

namespace UndoApi.Models.Enums;

/// <summary>
/// What the merchant decides about an order.
/// </summary>
[JsonConverter(typeof(StringEnumConverter<ResolveAction>))]
public sealed record ResolveAction : OpenStringEnum<ResolveAction>
{
    private ResolveAction(string value) : base(value)
    {
    }

    public static readonly ResolveAction AcceptClaim = new("accept_claim");

    public static readonly ResolveAction ReturnReceived = new("return_received");

    public static readonly ResolveAction RetrySettlement = new("retry_settlement");

    public TResult Match<TResult>(Func<TResult> onAcceptClaim,
        Func<TResult> onReturnReceived,
        Func<TResult> onRetrySettlement,
        Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == AcceptClaim => onAcceptClaim(),
            _ when this == ReturnReceived => onReturnReceived(),
            _ when this == RetrySettlement => onRetrySettlement(),
            _ => otherwise(Value)
        };

    public void Match(Action onAcceptClaim, Action onReturnReceived, Action onRetrySettlement, Action<string> otherwise)
    {
        if (this == AcceptClaim) onAcceptClaim();
        else if (this == ReturnReceived) onReturnReceived();
        else if (this == RetrySettlement) onRetrySettlement();
        else otherwise(Value);
    }
}
