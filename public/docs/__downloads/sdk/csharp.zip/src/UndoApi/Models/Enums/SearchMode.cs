using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Enum;

namespace UndoApi.Models.Enums;

/// <summary>
/// How the catalog reads the query.
/// </summary>
[JsonConverter(typeof(StringEnumConverter<SearchMode>))]
public sealed record SearchMode : OpenStringEnum<SearchMode>
{
    private SearchMode(string value) : base(value)
    {
    }

    public static readonly SearchMode Default = new("default");

    public static readonly SearchMode Agentic = new("agentic");

    public TResult Match<TResult>(Func<TResult> onDefault, Func<TResult> onAgentic, Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == Default => onDefault(),
            _ when this == Agentic => onAgentic(),
            _ => otherwise(Value)
        };

    public void Match(Action onDefault, Action onAgentic, Action<string> otherwise)
    {
        if (this == Default) onDefault();
        else if (this == Agentic) onAgentic();
        else otherwise(Value);
    }
}
