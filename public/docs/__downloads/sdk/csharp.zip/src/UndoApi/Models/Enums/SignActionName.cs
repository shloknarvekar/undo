using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Enum;

namespace UndoApi.Models.Enums;

/// <summary>
/// Always sign.
/// </summary>
[JsonConverter(typeof(StringEnumConverter<SignActionName>))]
public sealed record SignActionName : OpenStringEnum<SignActionName>
{
    private SignActionName(string value) : base(value)
    {
    }

    public static readonly SignActionName Sign = new("sign");

    public TResult Match<TResult>(Func<TResult> onSign, Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == Sign => onSign(),
            _ => otherwise(Value)
        };

    public void Match(Action onSign, Action<string> otherwise)
    {
        if (this == Sign) onSign();
        else otherwise(Value);
    }
}
