using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Enum;

namespace UndoApi.Models.Enums;

/// <summary>
/// Demo agents that misbehave on purpose.
/// </summary>
[JsonConverter(typeof(StringEnumConverter<SimulateMode>))]
public sealed record SimulateMode : OpenStringEnum<SimulateMode>
{
    private SimulateMode(string value) : base(value)
    {
    }

    public static readonly SimulateMode UnguardedWrongVariant = new("unguarded_wrong_variant");

    public TResult Match<TResult>(Func<TResult> onUnguardedWrongVariant, Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == UnguardedWrongVariant => onUnguardedWrongVariant(),
            _ => otherwise(Value)
        };

    public void Match(Action onUnguardedWrongVariant, Action<string> otherwise)
    {
        if (this == UnguardedWrongVariant) onUnguardedWrongVariant();
        else otherwise(Value);
    }
}
