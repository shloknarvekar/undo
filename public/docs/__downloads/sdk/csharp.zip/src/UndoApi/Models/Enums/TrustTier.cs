using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Enum;

namespace UndoApi.Models.Enums;

/// <summary>
/// An agent's trust band.
/// </summary>
[JsonConverter(typeof(StringEnumConverter<TrustTier>))]
public sealed record TrustTier : OpenStringEnum<TrustTier>
{
    private TrustTier(string value) : base(value)
    {
    }

    public static readonly TrustTier Trusted = new("trusted");

    public static readonly TrustTier Neutral = new("neutral");

    public static readonly TrustTier Risky = new("risky");

    public TResult Match<TResult>(Func<TResult> onTrusted,
        Func<TResult> onNeutral,
        Func<TResult> onRisky,
        Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == Trusted => onTrusted(),
            _ when this == Neutral => onNeutral(),
            _ when this == Risky => onRisky(),
            _ => otherwise(Value)
        };

    public void Match(Action onTrusted, Action onNeutral, Action onRisky, Action<string> otherwise)
    {
        if (this == Trusted) onTrusted();
        else if (this == Neutral) onNeutral();
        else if (this == Risky) onRisky();
        else otherwise(Value);
    }
}
