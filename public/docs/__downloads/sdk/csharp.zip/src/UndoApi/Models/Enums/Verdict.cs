using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Enum;

namespace UndoApi.Models.Enums;

/// <summary>
/// Who was at fault.
/// </summary>
[JsonConverter(typeof(StringEnumConverter<Verdict>))]
public sealed record Verdict : OpenStringEnum<Verdict>
{
    private Verdict(string value) : base(value)
    {
    }

    public static readonly Verdict AgentFault = new("AGENT_FAULT");

    public static readonly Verdict MerchantFault = new("MERCHANT_FAULT");

    public static readonly Verdict ShopperChangedMind = new("SHOPPER_CHANGED_MIND");

    public static readonly Verdict Inconclusive = new("INCONCLUSIVE");

    public TResult Match<TResult>(Func<TResult> onAgentFault,
        Func<TResult> onMerchantFault,
        Func<TResult> onShopperChangedMind,
        Func<TResult> onInconclusive,
        Func<string, TResult> otherwise) =>
        this switch
        {
            _ when this == AgentFault => onAgentFault(),
            _ when this == MerchantFault => onMerchantFault(),
            _ when this == ShopperChangedMind => onShopperChangedMind(),
            _ when this == Inconclusive => onInconclusive(),
            _ => otherwise(Value)
        };

    public void Match(Action onAgentFault,
        Action onMerchantFault,
        Action onShopperChangedMind,
        Action onInconclusive,
        Action<string> otherwise)
    {
        if (this == AgentFault) onAgentFault();
        else if (this == MerchantFault) onMerchantFault();
        else if (this == ShopperChangedMind) onShopperChangedMind();
        else if (this == Inconclusive) onInconclusive();
        else otherwise(Value);
    }
}
