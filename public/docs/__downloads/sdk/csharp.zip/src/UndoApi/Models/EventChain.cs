using System.Collections.Generic;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// The mandate's event chain, with a proof on every step.
/// </summary>
public record EventChain
{
    /// <summary>
    /// Every hash links correctly.
    /// </summary>
    [JsonPropertyName("intact")]
    public required bool Intact { get; init; }

    /// <summary>
    /// Events, oldest first.
    /// </summary>
    [JsonPropertyName("events")]
    public required IReadOnlyList<ChainEvent> Events { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
