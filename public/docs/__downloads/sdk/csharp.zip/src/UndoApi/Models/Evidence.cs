using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// Everything needed to verify an order without trusting Undo.
/// </summary>
public record Evidence
{
    /// <summary>
    /// Evidence file format.
    /// </summary>
    [JsonPropertyName("format")]
    public string Format { get; } = "undo-evidence-v1";

    /// <summary>
    /// The order this evidence is for.
    /// </summary>
    [JsonPropertyName("orderId")]
    public required Guid OrderId { get; init; }

    /// <summary>
    /// The signed mandate exactly as stored.
    /// </summary>
    [JsonPropertyName("mandate")]
    public required object? Mandate { get; init; }

    /// <summary>
    /// Raw events exactly as hashed. Each hash covers the previous hash and the canonical payload.
    /// </summary>
    [JsonPropertyName("events")]
    public required IReadOnlyList<object> Events { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
