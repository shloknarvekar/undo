using System.Text.Json.Serialization;
using UndoApi.Core.Models;
using UndoApi.Models.Enums;

namespace UndoApi.Models;

/// <summary>
/// One finding behind a verdict and where it came from.
/// </summary>
public record EvidenceItem
{
    /// <summary>
    /// Where a finding came from.
    /// </summary>
    [JsonPropertyName("source")]
    public required EvidenceSource Source { get; init; }

    /// <summary>
    /// The finding, in plain words.
    /// </summary>
    [JsonPropertyName("finding")]
    public required string Finding { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
