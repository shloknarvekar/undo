using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// Service health. Never includes secret values.
/// </summary>
public record HealthError
{
    /// <summary>
    /// True when every check that ran passed.
    /// </summary>
    [JsonPropertyName("ok")]
    public required bool Ok { get; init; }

    /// <summary>
    /// Always undo.
    /// </summary>
    [JsonPropertyName("service")]
    public required string Service { get; init; }

    /// <summary>
    /// Deployed commit, or <c>local</c>.
    /// </summary>
    [JsonPropertyName("commit")]
    public required string Commit { get; init; }

    /// <summary>
    /// Which integrations have credentials set. Never the values.
    /// </summary>
    [JsonPropertyName("configured")]
    public required ConfiguredIntegrations Configured { get; init; }

    /// <summary>
    /// With <c>deep</c>, <c>reachable</c> or the error.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("paypal")]
    public string? Paypal { get; init; }

    /// <summary>
    /// With deep: whether a live query worked, how long it took, and the shape of the connection URL (never credentials).
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("database")]
    public object? Database { get; init; }

    /// <summary>
    /// With deep: free-tier budget used so far today and this month.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("usage")]
    public object? Usage { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
