using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// A fresh check, run on every read.
/// </summary>
public record IntegrityCheck
{
    /// <summary>
    /// The stored digest matches the mandate recomputed now.
    /// </summary>
    [JsonPropertyName("digestMatches")]
    public required bool DigestMatches { get; init; }

    /// <summary>
    /// The shopper's signature verifies against the mandate.
    /// </summary>
    [JsonPropertyName("signatureValid")]
    public required bool SignatureValid { get; init; }

    /// <summary>
    /// Every event's hash links correctly to the one before.
    /// </summary>
    [JsonPropertyName("chainIntact")]
    public required bool ChainIntact { get; init; }

    /// <summary>
    /// The first event whose hash doesn't link, when the chain is broken.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("chainBrokenAt")]
    public int? ChainBrokenAt { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
