using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;
using UndoApi.Core.Validation.Attributes;
using UndoApi.Models.Enums;

namespace UndoApi.Models;

/// <summary>
/// The shopper's limits in structured form.
/// </summary>
public record IntentDraft
{
    /// <summary>
    /// What to buy, as a short noun phrase.
    /// </summary>
    [JsonPropertyName("item")]
    [MaxLength(120)]
    public required string Item { get; init; }

    /// <summary>
    /// Product category in plain words.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("category")]
    [MaxLength(60)]
    public string? Category { get; init; }

    /// <summary>
    /// How many to buy.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("quantity")]
    [Minimum(1)]
    [Maximum(20)]
    public int? Quantity { get; init; } = 1;

    /// <summary>
    /// Ceiling per item; 0 means no budget was given.
    /// </summary>
    [JsonPropertyName("maxPrice")]
    [Minimum(0.0)]
    public required double MaxPrice { get; init; }

    /// <summary>
    /// Currency of maxPrice.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("currency")]
    [StringLength(3, MinimumLength = 3)]
    public string? Currency { get; init; } = "USD";

    /// <summary>
    /// Required attribute values, keys lowercase.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("attributes")]
    public IReadOnlyDictionary<string, string>? Attributes { get; init; }

    /// <summary>
    /// Men's or women's products.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("gender")]
    public Gender? Gender { get; init; }

    /// <summary>
    /// Only these brands, if the shopper named any.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("brands")]
    [MaxLength(10)]
    public IReadOnlyList<string>? Brands { get; init; }

    /// <summary>
    /// ISO date the item must arrive by.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("deadline")]
    public string? Deadline { get; init; }

    /// <summary>
    /// Soft preferences that are not hard limits.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("notes")]
    [MaxLength(300)]
    public string? Notes { get; init; }

    /// <summary>
    /// Questions to answer before the draft can be signed.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("mustAsk")]
    [MaxLength(5)]
    public IReadOnlyList<string>? MustAsk { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
