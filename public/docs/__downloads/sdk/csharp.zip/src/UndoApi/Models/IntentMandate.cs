using System;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;
using UndoApi.Core.Validation.Attributes;
using UndoApi.Models.Enums;

namespace UndoApi.Models;

/// <summary>
/// What the shopper signs. Its canonical JSON (sorted keys) is hashed with SHA-256 for the signing message.
/// </summary>
public record IntentMandate
{
    /// <summary>
    /// Mandate format version. Always 1.
    /// </summary>
    [JsonPropertyName("version")]
    [Minimum(1)]
    [Maximum(1)]
    public required int Version { get; init; }

    /// <summary>
    /// Mandate id, chosen when it was prepared.
    /// </summary>
    [JsonPropertyName("id")]
    public required Guid Id { get; init; }

    /// <summary>
    /// When the mandate was prepared.
    /// </summary>
    [JsonPropertyName("createdAt")]
    public required DateTimeOffset CreatedAt { get; init; }

    /// <summary>
    /// When the mandate stops working (14 days after it was prepared).
    /// </summary>
    [JsonPropertyName("expiresAt")]
    public required DateTimeOffset ExpiresAt { get; init; }

    /// <summary>
    /// Base64 Ed25519 public key (32 bytes).
    /// </summary>
    [JsonPropertyName("shopperKey")]
    public required string ShopperKey { get; init; }

    /// <summary>
    /// The shopper's own words, verbatim.
    /// </summary>
    [JsonPropertyName("request")]
    [MaxLength(1000)]
    public required string Request { get; init; }

    /// <summary>
    /// The shopper's limits in structured form.
    /// </summary>
    [JsonPropertyName("intent")]
    public required IntentDraft Intent { get; init; }

    /// <summary>
    /// The agent a mandate authorizes. Inside the signed bytes, so liability follows the name.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("agent")]
    public AgentRef? Agent { get; init; }

    /// <summary>
    /// How the agent may pay.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("payWith")]
    public PayWith? PayWith { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
