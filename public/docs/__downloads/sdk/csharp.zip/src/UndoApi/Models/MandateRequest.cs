using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;
using UndoApi.Models.Enums;

namespace UndoApi.Models;

/// <summary>
/// A mandate an outside agent asked the shopper to sign.
/// </summary>
public record MandateRequest
{
    /// <summary>
    /// Mandate request id.
    /// </summary>
    [JsonPropertyName("id")]
    public required Guid Id { get; init; }

    /// <summary>
    /// The request as the agent passed it on, plus any answers.
    /// </summary>
    [JsonPropertyName("request")]
    public required string Request { get; init; }

    /// <summary>
    /// The shopper's limits in structured form.
    /// </summary>
    [JsonPropertyName("draft")]
    public required IntentDraft Draft { get; init; }

    /// <summary>
    /// Whether a draft can be signed as is.
    /// </summary>
    [JsonPropertyName("ready")]
    public required ReadyCheck Ready { get; init; }

    /// <summary>
    /// The agent a mandate authorizes. Inside the signed bytes, so liability follows the name.
    /// </summary>
    [JsonPropertyName("agent")]
    public required AgentRef Agent { get; init; }

    /// <summary>
    /// Where a mandate request stands.
    /// </summary>
    [JsonPropertyName("status")]
    public required MandateRequestStatus Status { get; init; }

    /// <summary>
    /// The signed mandate, once there is one.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("mandateId")]
    public Guid? MandateId { get; init; }

    /// <summary>
    /// When the request stops accepting a signature.
    /// </summary>
    [JsonPropertyName("expiresAt")]
    public required DateTimeOffset ExpiresAt { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
