using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// A mandate request that was signed and stored.
/// </summary>
public record MandateRequestSigned
{
    /// <summary>
    /// The stored mandate's id.
    /// </summary>
    [JsonPropertyName("mandateId")]
    public required Guid MandateId { get; init; }

    /// <summary>
    /// SHA-256 of the canonical mandate.
    /// </summary>
    [JsonPropertyName("digest")]
    public required string Digest { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
