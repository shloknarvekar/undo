using System.Collections.Generic;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;
using UndoApi.Models.Enums;

namespace UndoApi.Models;

/// <summary>
/// A mandate with its status, the search it permits, and a fresh integrity check.
/// </summary>
public record MandateView
{
    /// <summary>
    /// What the shopper signs. Its canonical JSON (sorted keys) is hashed with SHA-256 for the signing message.
    /// </summary>
    [JsonPropertyName("mandate")]
    public required IntentMandate Mandate { get; init; }

    /// <summary>
    /// Where a mandate stands.
    /// </summary>
    [JsonPropertyName("status")]
    public required MandateStatus Status { get; init; }

    /// <summary>
    /// The product search this mandate permits.
    /// </summary>
    [JsonPropertyName("search")]
    public required object Search { get; init; }

    /// <summary>
    /// A fresh check, run on every read.
    /// </summary>
    [JsonPropertyName("integrity")]
    public required IntegrityCheck Integrity { get; init; }

    /// <summary>
    /// The mandate's event chain, oldest first.
    /// </summary>
    [JsonPropertyName("events")]
    public required IReadOnlyList<ChainEventSummary> Events { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
