using System.Collections.Generic;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// Every agent that has shopped here and the store's rules.
/// </summary>
public record MerchantAgents
{
    /// <summary>
    /// The store's rules for agents. They apply from the next checkout.
    /// </summary>
    [JsonPropertyName("rules")]
    public required MerchantRules Rules { get; init; }

    /// <summary>
    /// Every agent that has shopped here, riskiest first.
    /// </summary>
    [JsonPropertyName("agents")]
    public required IReadOnlyList<AgentRecord> Agents { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
