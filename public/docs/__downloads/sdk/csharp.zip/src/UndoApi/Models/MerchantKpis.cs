using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// Headline numbers for the store.
/// </summary>
public record MerchantKpis
{
    /// <summary>
    /// Orders placed by agents (not counting abandoned checkouts).
    /// </summary>
    [JsonPropertyName("agentOrders")]
    public required int AgentOrders { get; init; }

    /// <summary>
    /// Orders that were undone.
    /// </summary>
    [JsonPropertyName("undone")]
    public required int Undone { get; init; }

    /// <summary>
    /// Estimated PayPal fees avoided by voiding instead of refunding.
    /// </summary>
    [JsonPropertyName("feesAvoided")]
    public required double FeesAvoided { get; init; }

    /// <summary>
    /// Money paid back to the store by agent operators through PayPal Payouts.
    /// </summary>
    [JsonPropertyName("billedToAgents")]
    public required double BilledToAgents { get; init; }

    /// <summary>
    /// Undos where the shopper changed their mind and the store was protected.
    /// </summary>
    [JsonPropertyName("merchantProtected")]
    public required int MerchantProtected { get; init; }

    /// <summary>
    /// Orders waiting for the store's decision.
    /// </summary>
    [JsonPropertyName("needsAction")]
    public required int NeedsAction { get; init; }

    /// <summary>
    /// Money held right now with an undo window open.
    /// </summary>
    [JsonPropertyName("heldNow")]
    public required double HeldNow { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
