using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;
using UndoApi.Models.Enums;

namespace UndoApi.Models;

/// <summary>
/// One agent order as the store sees it.
/// </summary>
public record MerchantOrder
{
    /// <summary>
    /// Undo order id.
    /// </summary>
    [JsonPropertyName("id")]
    public required Guid Id { get; init; }

    /// <summary>
    /// When the agent placed the order.
    /// </summary>
    [JsonPropertyName("createdAt")]
    public required DateTimeOffset CreatedAt { get; init; }

    /// <summary>
    /// Where an order stands. AUTHORIZED means the money is only held and Undo is a free void.
    /// </summary>
    [JsonPropertyName("status")]
    public required OrderStatus Status { get; init; }

    /// <summary>
    /// Order total.
    /// </summary>
    [JsonPropertyName("amount")]
    public required double Amount { get; init; }

    /// <summary>
    /// ISO 4217 currency code.
    /// </summary>
    [JsonPropertyName("currency")]
    public required string Currency { get; init; }

    /// <summary>
    /// Product title.
    /// </summary>
    [JsonPropertyName("product")]
    public required string Product { get; init; }

    /// <summary>
    /// Brand name, when known.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("brand")]
    public string? Brand { get; init; }

    /// <summary>
    /// The variant bought, for example Size M · Color Black.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("variant")]
    public string? Variant { get; init; }

    /// <summary>
    /// Product image URL, when there is one.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("imageUrl")]
    public string? ImageUrl { get; init; }

    /// <summary>
    /// The retailer's domain.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("retailer")]
    public string? Retailer { get; init; }

    /// <summary>
    /// The shopper's mandate, in their words.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("request")]
    public string? Request { get; init; }

    /// <summary>
    /// How sure the agent was that the item fits, from 0 to 1.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("agentConfidence")]
    public double? AgentConfidence { get; init; }

    /// <summary>
    /// True when the agent skipped Undo's checks before buying.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("guardBypassed")]
    public bool? GuardBypassed { get; init; }

    /// <summary>
    /// Set on demo orders from the careless test agent.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("simulated")]
    public string? Simulated { get; init; }

    /// <summary>
    /// The agent operator's name.
    /// </summary>
    [JsonPropertyName("agentName")]
    public required string AgentName { get; init; }

    /// <summary>
    /// Whether the operator presented a registered key.
    /// </summary>
    [JsonPropertyName("agentVerified")]
    public required bool AgentVerified { get; init; }

    /// <summary>
    /// How the agent connected: web or mcp.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("agentVia")]
    public string? AgentVia { get; init; }

    /// <summary>
    /// The fault check's verdict, after an Undo.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("verdict")]
    public string? Verdict { get; init; }

    /// <summary>
    /// How sure the verdict is, from 0 to 1.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("verdictConfidence")]
    public double? VerdictConfidence { get; init; }

    /// <summary>
    /// Who pays: agent_operator, merchant or shopper.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("liability")]
    public string? Liability { get; init; }

    /// <summary>
    /// Status of the agent operator's payout to the store, when one was due.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("settlement")]
    public string? Settlement { get; init; }

    /// <summary>
    /// Money that arrived from an agent operator through PayPal Payouts.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("settledAmount")]
    public double? SettledAmount { get; init; }

    /// <summary>
    /// What happened to the money, for example VOID or REFUND_FULL.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("action")]
    public string? Action { get; init; }

    /// <summary>
    /// When the undo window closes or closed.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("windowEndsAt")]
    public DateTimeOffset? WindowEndsAt { get; init; }

    /// <summary>
    /// Minutes left in the undo window, while the money is held.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("windowMinutesLeft")]
    public int? WindowMinutesLeft { get; init; }

    /// <summary>
    /// The most specific PayPal id: capture, then authorization, then order.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("paypalRef")]
    public string? PaypalRef { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
