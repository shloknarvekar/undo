using System.Collections.Generic;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// The store's agent orders and headline numbers.
/// </summary>
public record MerchantOrders
{
    /// <summary>
    /// Headline numbers for the store.
    /// </summary>
    [JsonPropertyName("kpis")]
    public required MerchantKpis Kpis { get; init; }

    /// <summary>
    /// Agent orders, newest first.
    /// </summary>
    [JsonPropertyName("orders")]
    public required IReadOnlyList<MerchantOrder> Orders { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
