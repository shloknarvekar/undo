using System.Text.Json.Serialization;
using UndoApi.Core.Models;
using UndoApi.Core.Validation.Attributes;

namespace UndoApi.Models;

/// <summary>
/// The store's rules for agents. They apply from the next checkout.
/// </summary>
public record MerchantRules
{
    /// <summary>
    /// Refuse agents scoring below this. Null turns it off.
    /// </summary>
    [JsonPropertyName("blockBelow")]
    [Minimum(1)]
    [Maximum(100)]
    public required int? BlockBelow { get; init; }

    /// <summary>
    /// Give agents scoring below this a longer window. Null turns it off.
    /// </summary>
    [JsonPropertyName("extendBelow")]
    [Minimum(1)]
    [Maximum(100)]
    public required int? ExtendBelow { get; init; }

    /// <summary>
    /// How much longer.
    /// </summary>
    [JsonPropertyName("extendMinutes")]
    [Minimum(15)]
    [Maximum(1440)]
    public required int ExtendMinutes { get; init; }

    /// <summary>
    /// Refuse agents without a registered operator key.
    /// </summary>
    [JsonPropertyName("blockUnverified")]
    public required bool BlockUnverified { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
