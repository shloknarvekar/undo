using System.Text.Json.Serialization;
using UndoApi.Core.Models;
using UndoApi.Models.Enums;

namespace UndoApi.Models;

/// <summary>
/// What happens to the money after the verdict.
/// </summary>
public record MoneyAction
{
    /// <summary>
    /// What happens to the money.
    /// </summary>
    [JsonPropertyName("type")]
    public required MoneyActionType Type { get; init; }

    /// <summary>
    /// Why, in plain words.
    /// </summary>
    [JsonPropertyName("reason")]
    public required string Reason { get; init; }

    /// <summary>
    /// On AUTHORIZE_RETURN, the amount refunded when the item comes back.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("refundOnReturn")]
    public string? RefundOnReturn { get; init; }

    /// <summary>
    /// On AUTHORIZE_RETURN.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("restockingFee")]
    public string? RestockingFee { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
