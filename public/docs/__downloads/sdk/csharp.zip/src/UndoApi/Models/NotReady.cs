using System.Collections.Generic;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;
using UndoApi.Models.Enums;

namespace UndoApi.Models;

/// <summary>
/// The draft can't be turned into a mandate yet.
/// </summary>
public record NotReady
{
    /// <summary>
    /// Why a draft can't be signed yet.
    /// </summary>
    [JsonPropertyName("error")]
    public required NotReadyReason Error { get; init; }

    /// <summary>
    /// The questions still to answer.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("mustAsk")]
    public IReadOnlyList<string>? MustAsk { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
