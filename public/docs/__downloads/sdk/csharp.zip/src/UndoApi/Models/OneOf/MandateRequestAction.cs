using System;
using System.Text.Json;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models.OneOf;

/// <summary>
/// One of answer, prepare or sign, chosen by action.
/// </summary>
[JsonConverter(typeof(MandateRequestActionConverter))]
public record MandateRequestAction
{
    private readonly Optional<AnswerAction> _answerActionValue;

    private readonly Optional<PrepareAction> _prepareActionValue;

    private readonly Optional<SignAction> _signActionValue;

    private MandateRequestAction(Optional<AnswerAction> answerActionValue,
        Optional<PrepareAction> prepareActionValue,
        Optional<SignAction> signActionValue)
    {
        _answerActionValue = answerActionValue;
        _prepareActionValue = prepareActionValue;
        _signActionValue = signActionValue;
    }

    public static MandateRequestAction AnswerAction(AnswerAction value) =>
        new(Optional<AnswerAction>.Some(value), default, default);

    public static MandateRequestAction PrepareAction(PrepareAction value) =>
        new(default, Optional<PrepareAction>.Some(value), default);

    public static MandateRequestAction SignAction(SignAction value) =>
        new(default, default, Optional<SignAction>.Some(value));

    public bool TryGetAnswerAction(out AnswerAction value) => _answerActionValue.TryGetValue(out value);

    public bool TryGetPrepareAction(out PrepareAction value) => _prepareActionValue.TryGetValue(out value);

    public bool TryGetSignAction(out SignAction value) => _signActionValue.TryGetValue(out value);

    public static implicit operator MandateRequestAction(AnswerAction value) => AnswerAction(value);

    public static implicit operator MandateRequestAction(PrepareAction value) => PrepareAction(value);

    public static implicit operator MandateRequestAction(SignAction value) => SignAction(value);
}

file sealed class MandateRequestActionConverter : JsonConverter<MandateRequestAction>
{
    public override MandateRequestAction Read(ref Utf8JsonReader reader,
        Type typeToConvert,
        JsonSerializerOptions options)
    {
        using var doc = JsonDocument.ParseValue(ref reader);
        var root = doc.RootElement;
        if (!root.TryGetProperty("action", out var typeProperty))
        {
            throw new JsonException("Missing required 'action' discriminator field");
        }
        var discriminator = typeProperty.GetString();
        return discriminator switch
        {
            "answer" => MandateRequestAction.AnswerAction(root.Deserialize<AnswerAction>(options)!),
            "prepare" => MandateRequestAction.PrepareAction(root.Deserialize<PrepareAction>(options)!),
            "sign" => MandateRequestAction.SignAction(root.Deserialize<SignAction>(options)!),
            _ => throw new JsonException(
                $"JSON does not match AnswerAction or PrepareAction or SignAction schemas: {root.ToString()}")
        };
    }

    public override void Write(Utf8JsonWriter writer, MandateRequestAction value, JsonSerializerOptions options)
    {
        if (value.TryGetAnswerAction(out var answerActionValue))
        {
            JsonSerializer.Serialize(writer, answerActionValue, options);
        }
        else if (value.TryGetPrepareAction(out var prepareActionValue))
        {
            JsonSerializer.Serialize(writer, prepareActionValue, options);
        }
        else if (value.TryGetSignAction(out var signActionValue))
        {
            JsonSerializer.Serialize(writer, signActionValue, options);
        }
        else
        {
            throw new JsonException($"{nameof(MandateRequestAction)} contains no valid value to serialize.");
        }
    }
}
