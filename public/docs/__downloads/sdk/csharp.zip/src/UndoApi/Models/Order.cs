using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;
using UndoApi.Models.Enums;

namespace UndoApi.Models;

/// <summary>
/// The purchase.
/// </summary>
public record Order
{
    /// <summary>
    /// Undo order id.
    /// </summary>
    [JsonPropertyName("id")]
    public required Guid Id { get; init; }

    /// <summary>
    /// Where an order stands. AUTHORIZED means the money is only held and Undo is a free void.
    /// </summary>
    [JsonPropertyName("status")]
    public required OrderStatus Status { get; init; }

    /// <summary>
    /// Total held or charged, as a decimal string.
    /// </summary>
    [JsonPropertyName("amount")]
    public required string Amount { get; init; }

    /// <summary>
    /// ISO 4217 currency code.
    /// </summary>
    [JsonPropertyName("currency")]
    public required string Currency { get; init; }

    /// <summary>
    /// Number of items.
    /// </summary>
    [JsonPropertyName("quantity")]
    public required int Quantity { get; init; }

    /// <summary>
    /// A catalog product resolved to one offer and one exact variant.
    /// </summary>
    [JsonPropertyName("product")]
    public required Product Product { get; init; }

    /// <summary>
    /// The agent's reasoning, confidence, guard checks and operator, as recorded at checkout.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("agent")]
    public object? Agent { get; init; }

    /// <summary>
    /// The PayPal ids behind this order.
    /// </summary>
    [JsonPropertyName("paypal")]
    public required PayPalIds Paypal { get; init; }

    /// <summary>
    /// The latest Undo, with verdict, evidence, money action and any agent payout.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("resolution")]
    public object? Resolution { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
