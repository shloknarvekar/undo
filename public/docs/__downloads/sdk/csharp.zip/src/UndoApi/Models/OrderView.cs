using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// An order, its undo window, its mandate and its verified event chain.
/// </summary>
public record OrderView
{
    /// <summary>
    /// The purchase.
    /// </summary>
    [JsonPropertyName("order")]
    public required Order Order { get; init; }

    /// <summary>
    /// The undo window on an order: how long, why, and whether it is still open.
    /// </summary>
    [JsonPropertyName("undoWindow")]
    public required UndoWindowStatus UndoWindow { get; init; }

    /// <summary>
    /// The mandate this purchase was made under.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("mandate")]
    public MandateSummary? Mandate { get; init; }

    /// <summary>
    /// The mandate's event chain, with a proof on every step.
    /// </summary>
    [JsonPropertyName("chain")]
    public required EventChain Chain { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
