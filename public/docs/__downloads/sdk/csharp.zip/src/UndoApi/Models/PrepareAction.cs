using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;
using UndoApi.Models.Enums;

namespace UndoApi.Models;

/// <summary>
/// Build the exact mandate this device will sign.
/// </summary>
public record PrepareAction
{
    /// <summary>
    /// Always prepare.
    /// </summary>
    [JsonPropertyName("action")]
    public string Action { get; } = "prepare";

    /// <summary>
    /// Base64 Ed25519 public key of the device that will sign.
    /// </summary>
    [JsonPropertyName("shopperKey")]
    [StringLength(60, MinimumLength = 40)]
    public required string ShopperKey { get; init; }

    /// <summary>
    /// How the agent may pay.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("payWith")]
    public PayWith? PayWith { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
