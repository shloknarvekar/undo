using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;
using UndoApi.Models.Enums;

namespace UndoApi.Models;

/// <summary>
/// What's needed to build the exact mandate a device will sign.
/// </summary>
public record PrepareMandate
{
    /// <summary>
    /// The shopper's request in their own words, kept verbatim inside the mandate.
    /// </summary>
    [JsonPropertyName("request")]
    [StringLength(1000, MinimumLength = 3)]
    public required string Request { get; init; }

    /// <summary>
    /// The shopper's limits in structured form.
    /// </summary>
    [JsonPropertyName("draft")]
    public required IntentDraft Draft { get; init; }

    /// <summary>
    /// Base64 Ed25519 public key.
    /// </summary>
    [JsonPropertyName("shopperKey")]
    [StringLength(60, MinimumLength = 40)]
    public required string ShopperKey { get; init; }

    /// <summary>
    /// How the agent may pay.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("payWith")]
    public PayWith? PayWith { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
