using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// The mandate to sign and the exact string to sign.
/// </summary>
public record PreparedMandate
{
    /// <summary>
    /// What the shopper signs. Its canonical JSON (sorted keys) is hashed with SHA-256 for the signing message.
    /// </summary>
    [JsonPropertyName("mandate")]
    public required IntentMandate Mandate { get; init; }

    /// <summary>
    /// Sign these exact UTF-8 bytes with the shopper's Ed25519 key.
    /// </summary>
    [JsonPropertyName("signingMessage")]
    public required string SigningMessage { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
