using System.Collections.Generic;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// A catalog product resolved to one offer and one exact variant.
/// </summary>
public record Product
{
    /// <summary>
    /// Catalog product id. Use it with getProduct.
    /// </summary>
    [JsonPropertyName("channel3Id")]
    public required string Channel3Id { get; init; }

    /// <summary>
    /// Product title.
    /// </summary>
    [JsonPropertyName("title")]
    public required string Title { get; init; }

    /// <summary>
    /// Brand name, when known.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("brand")]
    public string? Brand { get; init; }

    /// <summary>
    /// Product description from the retailer, when there is one.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("description")]
    public string? Description { get; init; }

    /// <summary>
    /// Price of the chosen offer, per item.
    /// </summary>
    [JsonPropertyName("price")]
    public required double Price { get; init; }

    /// <summary>
    /// ISO 4217 currency code.
    /// </summary>
    [JsonPropertyName("currency")]
    public required string Currency { get; init; }

    /// <summary>
    /// Product image URL, when there is one.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("imageUrl")]
    public string? ImageUrl { get; init; }

    /// <summary>
    /// Where the product is sold.
    /// </summary>
    [JsonPropertyName("sourceUrl")]
    public required string SourceUrl { get; init; }

    /// <summary>
    /// The retailer's domain.
    /// </summary>
    [JsonPropertyName("sourceDomain")]
    public required string SourceDomain { get; init; }

    /// <summary>
    /// Colors of the product as hex codes.
    /// </summary>
    [JsonPropertyName("colors")]
    public required IReadOnlyList<string> Colors { get; init; }

    /// <summary>
    /// Catalog attributes. Each value is a list of strings, for example activity: [Running].
    /// </summary>
    [JsonPropertyName("attributes")]
    public required object Attributes { get; init; }

    /// <summary>
    /// The exact variant this offer resolves to, for example Size M and Color Black.
    /// </summary>
    [JsonPropertyName("variant")]
    public required IReadOnlyDictionary<string, string> Variant { get; init; }

    /// <summary>
    /// Every option the product comes in, with its values.
    /// </summary>
    [JsonPropertyName("variantOptions")]
    public required IReadOnlyList<VariantOption> VariantOptions { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
