using System.Collections.Generic;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// A product at the requested variant, plus any option the catalog couldn't honor.
/// </summary>
public record ProductDetail
{
    /// <summary>
    /// A catalog product resolved to one offer and one exact variant.
    /// </summary>
    [JsonPropertyName("product")]
    public required Product Product { get; init; }

    /// <summary>
    /// Requested options the catalog could not honor.
    /// </summary>
    [JsonPropertyName("relaxed")]
    public required IReadOnlyList<object> Relaxed { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
