using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;
using UndoApi.Core.Validation.Attributes;
using UndoApi.Models.Enums;

namespace UndoApi.Models;

/// <summary>
/// A catalog search with structured filters.
/// </summary>
public record ProductSearch
{
    /// <summary>
    /// What to search for, in plain words.
    /// </summary>
    [JsonPropertyName("query")]
    [StringLength(500, MinimumLength = 1)]
    public required string Query { get; init; }

    /// <summary>
    /// Highest price per item.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("maxPrice")]
    [Minimum(0.01)]
    public double? MaxPrice { get; init; }

    /// <summary>
    /// Lowest price per item.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("minPrice")]
    [Minimum(0.0)]
    public double? MinPrice { get; init; }

    /// <summary>
    /// Color name, for example black.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("color")]
    [MaxLength(30)]
    public string? Color { get; init; }

    /// <summary>
    /// Plain-words category, resolved server-side.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("category")]
    [MaxLength(60)]
    public string? Category { get; init; }

    /// <summary>
    /// Men's or women's products.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("gender")]
    public Gender? Gender { get; init; }

    /// <summary>
    /// How many products to return.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("limit")]
    [Minimum(1)]
    [Maximum(30)]
    public int? Limit { get; init; }

    /// <summary>
    /// How the catalog reads the query.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("mode")]
    public SearchMode? Mode { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
