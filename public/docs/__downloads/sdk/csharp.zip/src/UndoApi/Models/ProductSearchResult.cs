using System.Collections.Generic;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// Search results.
/// </summary>
public record ProductSearchResult
{
    /// <summary>
    /// The catalog category the search was narrowed to.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("category")]
    public string? Category { get; init; }

    /// <summary>
    /// Products that have at least one offer.
    /// </summary>
    [JsonPropertyName("products")]
    public required IReadOnlyList<Product> Products { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
