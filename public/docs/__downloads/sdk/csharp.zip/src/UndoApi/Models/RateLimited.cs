using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// Returned with 429 when this visitor made too many requests or a free-tier budget is spent.
/// </summary>
public record RateLimited
{
    /// <summary>
    /// The error code on a 429.
    /// </summary>
    [JsonPropertyName("error")]
    public string Error { get; } = "rate_limited";

    /// <summary>
    /// What happened and how long to wait, in plain words.
    /// </summary>
    [JsonPropertyName("detail")]
    public required string Detail { get; init; }

    /// <summary>
    /// Seconds to wait.
    /// </summary>
    [JsonPropertyName("retryAfter")]
    public required int RetryAfter { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
