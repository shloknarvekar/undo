using System.Text.Json.Serialization;
using UndoApi.Core.Models;
using UndoApi.Models.Enums;

namespace UndoApi.Models;

/// <summary>
/// What the merchant decided.
/// </summary>
public record ResolveOrderRequest
{
    /// <summary>
    /// What the merchant decides about an order.
    /// </summary>
    [JsonPropertyName("action")]
    public required ResolveAction Action { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
