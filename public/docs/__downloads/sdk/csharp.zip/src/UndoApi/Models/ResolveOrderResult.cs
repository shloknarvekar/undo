using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// What the merchant's decision did.
/// </summary>
public record ResolveOrderResult
{
    /// <summary>
    /// The order that was resolved.
    /// </summary>
    [JsonPropertyName("orderId")]
    public required Guid OrderId { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
