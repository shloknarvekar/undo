using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// What the store's rules do to this agent's next purchase.
/// </summary>
public record RuleEffect
{
    /// <summary>
    /// Why the agent would be refused, or null.
    /// </summary>
    [JsonPropertyName("blocked")]
    public required string? Blocked { get; init; }

    /// <summary>
    /// Extra undo-window minutes the rules add.
    /// </summary>
    [JsonPropertyName("extraMinutes")]
    public required int ExtraMinutes { get; init; }

    /// <summary>
    /// Which rule added the time, or null.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("reason")]
    public string? Reason { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
