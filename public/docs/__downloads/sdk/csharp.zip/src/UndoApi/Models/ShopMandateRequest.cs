using System.Text.Json.Serialization;
using UndoApi.Core.Models;
using UndoApi.Models.Enums;

namespace UndoApi.Models;

/// <summary>
/// Options for a shopping run. Send an empty object for a normal run.
/// </summary>
public record ShopMandateRequest
{
    /// <summary>
    /// Demo agents that misbehave on purpose.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("simulate")]
    public SimulateMode? Simulate { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
