using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;
using UndoApi.Models.Enums;

namespace UndoApi.Models;

/// <summary>
/// A checkout opened by Undo's agent inside a mandate.
/// </summary>
public record ShopResult
{
    /// <summary>
    /// The new order. Read it with getOrder.
    /// </summary>
    [JsonPropertyName("orderId")]
    public required Guid OrderId { get; init; }

    /// <summary>
    /// Where the shopper approves the payment in PayPal (absent when paid with a saved wallet).
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("approveUrl")]
    public string? ApproveUrl { get; init; }

    /// <summary>
    /// Where a new checkout stands.
    /// </summary>
    [JsonPropertyName("status")]
    public required CheckoutStatus Status { get; init; }

    /// <summary>
    /// When the undo window closes, once the money is held.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("windowEndsAt")]
    public DateTimeOffset? WindowEndsAt { get; init; }

    /// <summary>
    /// How a purchase was paid.
    /// </summary>
    [JsonPropertyName("paidWith")]
    public required PaidWith PaidWith { get; init; }

    /// <summary>
    /// Why a saved wallet was not used, when the mandate allowed one.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("walletNote")]
    public string? WalletNote { get; init; }

    /// <summary>
    /// What the agent put in the cart.
    /// </summary>
    [JsonPropertyName("cart")]
    public required Cart Cart { get; init; }

    /// <summary>
    /// The agent's reasoning, confidence and the guard's checks.
    /// </summary>
    [JsonPropertyName("agent")]
    public required object Agent { get; init; }

    /// <summary>
    /// How long the shopper can undo for free, and why.
    /// </summary>
    [JsonPropertyName("undoWindow")]
    public required UndoWindow UndoWindow { get; init; }

    /// <summary>
    /// An agent's trust score at this store, with every point explained.
    /// </summary>
    [JsonPropertyName("trust")]
    public required Trust Trust { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
