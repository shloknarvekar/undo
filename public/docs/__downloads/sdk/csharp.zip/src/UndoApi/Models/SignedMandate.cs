using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// A mandate and the shopper's signature over its signing message.
/// </summary>
public record SignedMandate
{
    /// <summary>
    /// What the shopper signs. Its canonical JSON (sorted keys) is hashed with SHA-256 for the signing message.
    /// </summary>
    [JsonPropertyName("mandate")]
    public required IntentMandate Mandate { get; init; }

    /// <summary>
    /// Base64 Ed25519 signature of the signing message.
    /// </summary>
    [JsonPropertyName("signature")]
    [StringLength(100, MinimumLength = 80)]
    public required string Signature { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
