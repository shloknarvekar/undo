using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// A stored mandate and the first event of its hash chain.
/// </summary>
public record StoredMandate
{
    /// <summary>
    /// The stored mandate's id.
    /// </summary>
    [JsonPropertyName("id")]
    public required Guid Id { get; init; }

    /// <summary>
    /// SHA-256 (hex) of the mandate's canonical JSON.
    /// </summary>
    [JsonPropertyName("digest")]
    public required string Digest { get; init; }

    /// <summary>
    /// The first event in the mandate's hash chain (MANDATE_SIGNED).
    /// </summary>
    [JsonPropertyName("event")]
    public required ChainEventRef Event { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
