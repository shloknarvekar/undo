using System.Collections.Generic;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;
using UndoApi.Core.Validation.Attributes;
using UndoApi.Models.Enums;

namespace UndoApi.Models;

/// <summary>
/// An agent's trust score at this store, with every point explained.
/// </summary>
public record Trust
{
    /// <summary>
    /// 0 to 100, from the agent's record at this store.
    /// </summary>
    [JsonPropertyName("score")]
    [Minimum(0)]
    [Maximum(100)]
    public required int Score { get; init; }

    /// <summary>
    /// An agent's trust band.
    /// </summary>
    [JsonPropertyName("tier")]
    public required TrustTier Tier { get; init; }

    /// <summary>
    /// Every point in the score, explained.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("factors")]
    public IReadOnlyList<TrustFactor>? Factors { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
