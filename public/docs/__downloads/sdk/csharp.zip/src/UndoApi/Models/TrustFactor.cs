using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// One part of an agent's trust score.
/// </summary>
public record TrustFactor
{
    /// <summary>
    /// What earned or cost points.
    /// </summary>
    [JsonPropertyName("label")]
    public required string Label { get; init; }

    /// <summary>
    /// Points added (negative when taken away).
    /// </summary>
    [JsonPropertyName("points")]
    public required int Points { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
