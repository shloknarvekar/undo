using System.Collections.Generic;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;
using UndoApi.Models.Enums;

namespace UndoApi.Models;

/// <summary>
/// What happened to the money and the order's new status.
/// </summary>
public record UndoOutcome
{
    /// <summary>
    /// What happens to the money after the verdict.
    /// </summary>
    [JsonPropertyName("action")]
    public required MoneyAction Action { get; init; }

    /// <summary>
    /// Where an order stands. AUTHORIZED means the money is only held and Undo is a free void.
    /// </summary>
    [JsonPropertyName("status")]
    public required OrderStatus Status { get; init; }

    /// <summary>
    /// The PayPal ids behind the money movement.
    /// </summary>
    [JsonPropertyName("paypal")]
    public required IReadOnlyDictionary<string, string?> Paypal { get; init; }

    /// <summary>
    /// SHA-256 of the evidence pack sent with a merchant claim.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("evidenceDigest")]
    public string? EvidenceDigest { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
