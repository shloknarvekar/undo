using System;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// An Undo, signed by the shopper's device key.
/// </summary>
public record UndoRequest
{
    /// <summary>
    /// What went wrong, in the shopper's words.
    /// </summary>
    [JsonPropertyName("reason")]
    [StringLength(500, MinimumLength = 3)]
    public required string Reason { get; init; }

    /// <summary>
    /// Optional photo of what arrived, as a base64 JPEG, PNG or WebP data URL (max 4 MB).
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("photo")]
    [RegularExpression("^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$")]
    public string? Photo { get; init; }

    /// <summary>
    /// When the shopper pressed Undo. Must be within 15 minutes of the server's clock.
    /// </summary>
    [JsonPropertyName("requestedAt")]
    public required DateTimeOffset RequestedAt { get; init; }

    /// <summary>
    /// Base64 Ed25519 signature of the undo signing message.
    /// </summary>
    [JsonPropertyName("signature")]
    [StringLength(100, MinimumLength = 80)]
    public required string Signature { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
