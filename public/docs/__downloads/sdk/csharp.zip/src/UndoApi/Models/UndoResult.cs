using System;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// The verdict and what happened to the money.
/// </summary>
public record UndoResult
{
    /// <summary>
    /// The order that was undone.
    /// </summary>
    [JsonPropertyName("orderId")]
    public required Guid OrderId { get; init; }

    /// <summary>
    /// The fault check's verdict, who pays, and the evidence behind it.
    /// </summary>
    [JsonPropertyName("decision")]
    public required Decision Decision { get; init; }

    /// <summary>
    /// What happened to the money and the order's new status.
    /// </summary>
    [JsonPropertyName("outcome")]
    public required UndoOutcome Outcome { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
