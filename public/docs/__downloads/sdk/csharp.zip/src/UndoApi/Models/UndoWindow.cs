using System.Collections.Generic;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// How long the shopper can undo for free, and why.
/// </summary>
public record UndoWindow
{
    /// <summary>
    /// Total window length.
    /// </summary>
    [JsonPropertyName("minutes")]
    public required int Minutes { get; init; }

    /// <summary>
    /// Why the window is this long, factor by factor.
    /// </summary>
    [JsonPropertyName("factors")]
    public required IReadOnlyList<UndoWindowFactor> Factors { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
