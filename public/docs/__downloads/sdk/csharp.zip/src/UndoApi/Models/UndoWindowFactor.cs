using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// One reason the undo window is as long as it is.
/// </summary>
public record UndoWindowFactor
{
    /// <summary>
    /// What added time, in plain words.
    /// </summary>
    [JsonPropertyName("factor")]
    public required string Factor { get; init; }

    /// <summary>
    /// Minutes it added.
    /// </summary>
    [JsonPropertyName("minutes")]
    public required int Minutes { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
