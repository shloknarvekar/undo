using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;
using UndoApi.Core.Models;

namespace UndoApi.Models;

/// <summary>
/// The undo window on an order: how long, why, and whether it is still open.
/// </summary>
public record UndoWindowStatus
{
    /// <summary>
    /// Total window length.
    /// </summary>
    [JsonPropertyName("minutes")]
    public required int Minutes { get; init; }

    /// <summary>
    /// Why the window is this long, factor by factor.
    /// </summary>
    [JsonPropertyName("factors")]
    public required IReadOnlyList<UndoWindowFactor> Factors { get; init; }

    /// <summary>
    /// When the window closes.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("endsAt")]
    public DateTimeOffset? EndsAt { get; init; }

    /// <summary>
    /// True while the money is only held and the window hasn't closed: Undo is a free void.
    /// </summary>
    [JsonPropertyName("open")]
    public required bool Open { get; init; }

    /// <summary>
    /// Minutes until the window closes.
    /// </summary>
    [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
    [JsonPropertyName("minutesLeft")]
    public int? MinutesLeft { get; init; }

    [JsonExtensionData]
    public AdditionalProperties AdditionalProperties { get; init; } = [];
}
