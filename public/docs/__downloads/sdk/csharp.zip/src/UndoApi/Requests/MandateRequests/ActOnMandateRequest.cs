using System;
using UndoApi.Models.OneOf;

namespace UndoApi.Requests.MandateRequests;

/// <summary>
/// The inputs of the ActOnMandateRequest operation.
/// </summary>
public sealed record ActOnMandateRequest
{
    /// <summary>
    /// Mandate request id.
    /// </summary>
    public required Guid RequestId { get; init; }

    /// <summary>
    /// The shopper's answer, a request to prepare the mandate, or the signed mandate.
    /// </summary>
    public required MandateRequestAction Body { get; init; }
}
