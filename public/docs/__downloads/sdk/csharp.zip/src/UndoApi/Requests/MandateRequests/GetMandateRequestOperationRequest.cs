using System;

namespace UndoApi.Requests.MandateRequests;

/// <summary>
/// The inputs of the GetMandateRequest operation.
/// </summary>
public sealed record GetMandateRequestOperationRequest
{
    /// <summary>
    /// Mandate request id.
    /// </summary>
    public required Guid RequestId { get; init; }
}
