using UndoApi.Models;

namespace UndoApi.Requests.Mandates;

/// <summary>
/// The inputs of the DraftMandate operation.
/// </summary>
public sealed record DraftMandateOperationRequest
{
    /// <summary>
    /// The shopper's request in their own words.
    /// </summary>
    public required DraftMandateRequest Body { get; init; }
}
