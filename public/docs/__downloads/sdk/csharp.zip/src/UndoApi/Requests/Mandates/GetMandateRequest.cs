using System;

namespace UndoApi.Requests.Mandates;

/// <summary>
/// The inputs of the GetMandate operation.
/// </summary>
public sealed record GetMandateRequest
{
    /// <summary>
    /// Mandate id.
    /// </summary>
    public required Guid MandateId { get; init; }
}
