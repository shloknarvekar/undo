using UndoApi.Models;

namespace UndoApi.Requests.Mandates;

/// <summary>
/// The inputs of the PrepareMandate operation.
/// </summary>
public sealed record PrepareMandateRequest
{
    /// <summary>
    /// The draft, the shopper's words and the device key that will sign.
    /// </summary>
    public required PrepareMandate Body { get; init; }
}
