using UndoApi.Models;

namespace UndoApi.Requests.Mandates;

/// <summary>
/// The inputs of the StoreMandate operation.
/// </summary>
public sealed record StoreMandateRequest
{
    /// <summary>
    /// The mandate and the shopper's signature over it.
    /// </summary>
    public required SignedMandate Body { get; init; }
}
