using UndoApi.Core.Validation.Attributes;

namespace UndoApi.Requests.Merchant;

/// <summary>
/// The inputs of the ListMerchantActivity operation.
/// </summary>
public sealed record ListMerchantActivityRequest
{
    /// <summary>
    /// Only events with an id greater than this.
    /// </summary>
    [Minimum(0)]
    public int? After { get; init; }
}
