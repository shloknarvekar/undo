using System;
using UndoApi.Models;

namespace UndoApi.Requests.Merchant;

/// <summary>
/// The inputs of the ResolveOrder operation.
/// </summary>
public sealed record ResolveOrderOperationRequest
{
    /// <summary>
    /// Undo order id.
    /// </summary>
    public required Guid OrderId { get; init; }

    /// <summary>
    /// The merchant's decision.
    /// </summary>
    public required ResolveOrderRequest Body { get; init; }
}
