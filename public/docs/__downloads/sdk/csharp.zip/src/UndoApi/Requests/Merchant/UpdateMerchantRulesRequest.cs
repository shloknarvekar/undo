using UndoApi.Models;

namespace UndoApi.Requests.Merchant;

/// <summary>
/// The inputs of the UpdateMerchantRules operation.
/// </summary>
public sealed record UpdateMerchantRulesRequest
{
    /// <summary>
    /// The rules to apply from the next checkout.
    /// </summary>
    public required MerchantRules Body { get; init; }
}
