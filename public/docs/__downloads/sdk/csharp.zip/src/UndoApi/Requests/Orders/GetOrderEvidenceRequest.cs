using System;

namespace UndoApi.Requests.Orders;

/// <summary>
/// The inputs of the GetOrderEvidence operation.
/// </summary>
public sealed record GetOrderEvidenceRequest
{
    /// <summary>
    /// Undo order id.
    /// </summary>
    public required Guid OrderId { get; init; }
}
