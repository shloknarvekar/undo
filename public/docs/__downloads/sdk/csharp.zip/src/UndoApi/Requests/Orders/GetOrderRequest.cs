using System;

namespace UndoApi.Requests.Orders;

/// <summary>
/// The inputs of the GetOrder operation.
/// </summary>
public sealed record GetOrderRequest
{
    /// <summary>
    /// Undo order id.
    /// </summary>
    public required Guid OrderId { get; init; }
}
