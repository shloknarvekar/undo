using System;
using UndoApi.Models;

namespace UndoApi.Requests.Orders;

/// <summary>
/// The inputs of the UndoOrder operation.
/// </summary>
public sealed record UndoOrderRequest
{
    /// <summary>
    /// Undo order id.
    /// </summary>
    public required Guid OrderId { get; init; }

    /// <summary>
    /// Why the shopper is undoing, an optional photo, and their signature.
    /// </summary>
    public required UndoRequest Body { get; init; }
}
