using System.Collections.Generic;

namespace UndoApi.Requests.Products;

/// <summary>
/// The inputs of the GetProduct operation.
/// </summary>
public sealed record GetProductRequest
{
    /// <summary>
    /// Catalog product id (<c>channel3Id</c> from a search).
    /// </summary>
    public required string ProductId { get; init; }

    /// <summary>
    /// Variant options as <c>option_&lt;Name&gt;</c> keys.
    /// </summary>
    public IReadOnlyDictionary<string, string>? Options { get; init; }
}
