using UndoApi.Models;

namespace UndoApi.Requests.Products;

/// <summary>
/// The inputs of the SearchProducts operation.
/// </summary>
public sealed record SearchProductsRequest
{
    /// <summary>
    /// What to search for and how to filter it.
    /// </summary>
    public required ProductSearch Body { get; init; }
}
