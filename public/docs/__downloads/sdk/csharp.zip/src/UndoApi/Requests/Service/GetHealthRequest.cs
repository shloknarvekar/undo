namespace UndoApi.Requests.Service;

/// <summary>
/// The inputs of the GetHealth operation.
/// </summary>
public sealed record GetHealthRequest
{
    /// <summary>
    /// Present (any value) to also check PayPal and the database.
    /// </summary>
    public string? Deep { get; init; }
}
