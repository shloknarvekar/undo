using System;
using UndoApi.Models;

namespace UndoApi.Requests.Shopping;

/// <summary>
/// The inputs of the ShopMandate operation.
/// </summary>
public sealed record ShopMandateOperationRequest
{
    /// <summary>
    /// Mandate id.
    /// </summary>
    public required Guid MandateId { get; init; }

    /// <summary>
    /// Optional demo settings. Send {} for a normal run.
    /// </summary>
    public ShopMandateRequest? Body { get; init; }
}
