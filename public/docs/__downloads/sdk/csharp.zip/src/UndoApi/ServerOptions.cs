using UndoApi.Servers;

namespace UndoApi;

public class ServerOptions
{
    public DefaultOptions Default { get; set; } = new();
}
