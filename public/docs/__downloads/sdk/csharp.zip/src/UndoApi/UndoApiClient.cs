using System.Net.Http;
using UndoApi.Api;
using UndoApi.Core;
using UndoApi.Core.Logging;
using UndoApi.Core.Models;

namespace UndoApi;

/// <summary>
/// Ctrl+Z for AI agent purchases, built on PayPal.
/// <para>
/// Undo sits between a shopping agent and PayPal. A shopper signs a mandate (what the agent may buy, for how much)
/// with a key that never leaves their device. The agent shops inside it, PayPal only <b>authorizes</b> the money, and
/// an undo window opens. Pressing Undo runs a fault check and routes the money: a free void inside the window, or a
/// refund, a merchant claim or a return after capture. When the agent was at fault, its operator pays the merchant
/// back through PayPal Payouts. Every step is written to a hash-chained event log anyone can verify.
/// </para>
/// <para>
/// <b>Signing.</b> Mandates and undo requests are signed with Ed25519 by the shopper's device key. The API never
/// signs for a shopper. The exact strings to sign are given with each operation.
/// </para>
/// <para>
/// <b>Sandbox.</b> This deployment runs on the PayPal sandbox; no real money moves. Costly endpoints are rate limited
/// per visitor and answer <c>429</c> with a <c>Retry-After</c> header when the limit or the free-tier budget is reached.
/// </para>
/// <para>
/// <b>Agents.</b> Third-party agents usually connect over MCP (Streamable HTTP at <c>/api/mcp</c>, JSON-RPC, not described
/// here). This document covers the HTTP API that the web app, agents and merchants call directly.
/// </para>
/// </summary>
public sealed class UndoApiClient
{
    private readonly RawClient _rawClient;
    private readonly Server _server;

    public UndoApiClient(HttpClient httpClient, UndoApiClientOptions options)
    {
        _server = new Server(options.Environment, options.Server);
        var queryParameterFactory = new QueryParameterFactory([]);
        var templateParamsFactory = new TemplateParamsFactory([]);
        var urlFactory = new UriFactory(queryParameterFactory, templateParamsFactory);
        var httpStatusPolicy = new HttpStatusPolicy([]);
        var headersFactory = new HeadersFactory([
            new HeaderParam("User-Agent", "UndoApiClient/1.0.0 CSharp"),
            new HeaderParam("X-APIMatic-Lang", "CSharp"),
            new HeaderParam("X-APIMatic-Package-Version", "1.0.0"),
            new HeaderParam("X-APIMatic-Gen-Version", "4.0.0"),
            new HeaderParam("X-APIMatic-OS", RuntimeEnvironment.Os),
            new HeaderParam("X-APIMatic-Runtime", RuntimeEnvironment.Runtime),
        ]);
        var resiliencePipelineFactory = new ResiliencePipelineFactory(options.Retry, options.TimeProvider);
        var httpLogger = new HttpLogger(options.Logging, "UndoApiClient", options.TimeProvider);
        var responseContexts = new ResponseContextFactory(options.TimeProvider, options.StreamReadTimeout);
        _rawClient =
            new RawClient(
                httpClient,
                urlFactory,
                httpStatusPolicy,
                headersFactory,
                resiliencePipelineFactory,
                httpLogger,
                options.Hooks,
                responseContexts);
    }

    /// <summary>
    /// The shopper's side of a mandate an outside agent asked for.
    /// </summary>
    public MandateRequests MandateRequests => field ??= new MandateRequests(_rawClient, _server);

    /// <summary>
    /// Drafting, preparing, signing and reading shopper-signed intent mandates.
    /// </summary>
    public Mandates Mandates => field ??= new Mandates(_rawClient, _server);

    /// <summary>
    /// The store's view. Sandbox demo store; merchant sign-in comes with production use.
    /// </summary>
    public Merchant Merchant => field ??= new Merchant(_rawClient, _server);

    /// <summary>
    /// Purchases, their undo windows, the Undo button, and the evidence to verify them.
    /// </summary>
    public Orders Orders => field ??= new Orders(_rawClient, _server);

    /// <summary>
    /// Live product catalog search and detail, resolved to an exact variant.
    /// </summary>
    public Products Products => field ??= new Products(_rawClient, _server);

    /// <summary>
    /// Health and deploy checks.
    /// </summary>
    public Service Service => field ??= new Service(_rawClient, _server);

    /// <summary>
    /// Let Undo's agent shop inside a mandate and open a PayPal checkout that only authorizes the money.
    /// </summary>
    public Shopping Shopping => field ??= new Shopping(_rawClient, _server);
}
